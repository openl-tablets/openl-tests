package domain.ui.webstudio.components.common;

import com.microsoft.playwright.PlaywrightException;
import configuration.core.ui.WebElement;
import domain.ui.webstudio.components.BaseComponent;
import configuration.driver.DriverPool;
import helpers.utils.WaitUtil;

import java.util.List;

public class TableComponent extends BaseComponent {

    private static final String CELL_USAGE = "[starts-with(@data-testid,'cell-usage-')]";
    private static final String RAISED_CELL_TEXTS = """
            cells => cells.filter(cell => {
                const style = getComputedStyle(cell);
                const [red, green, blue] = (style.outlineColor.match(/\\d+/g) || []).map(Number);
                return style.outlineStyle === 'solid' && red > 2 * green && red > 2 * blue;
            }).map(cell => cell.innerText.trim())
            """;

    private WebElement allCells;
    private WebElement cellEditor;
    private WebElement firstRowLineNumber;
    private WebElement numberedFirstColumn;
    private List<PlaywrightTableRowComponent> rows;
    private WebElement propertyValueTemplate;

    public TableComponent() {
        super(DriverPool.getPage());
        initializeElements();
    }

    public TableComponent(WebElement rootLocator) {
        super(rootLocator);
        initializeElements();
    }

    private void initializeElements() {
        allCells = createScopedElement("xpath=.//td", "allCells");
        cellEditor = new WebElement(page, "xpath=//*[@data-testid='table-cell-input']", "cellEditor");
        firstRowLineNumber = createScopedElement("xpath=./tbody/tr[1]//span[@data-testid='table-line-number']", "firstRowLineNumber");
        numberedFirstColumn = createScopedElement("xpath=./tbody/tr[last()]/td[1][.//span[@data-testid='table-line-number']]", "numberedFirstColumn");
        rows = createScopedComponentList(PlaywrightTableRowComponent.class, "xpath=.//tbody/tr", "rowSelectorTemplate");
        propertyValueTemplate = createScopedElement("xpath=//tr/td[text()='%s']/following-sibling::td[1]", "propertyValue");
    }

    public void clickCell(int rowIndex, int columnIndex) {
        getCell(rowIndex, columnIndex).click();
    }

    public WebElement getCell(int rowIndex, int columnIndex) {
        WebElement[] drawn = new WebElement[1];
        WaitUtil.requireCondition(() -> {
            drawn[0] = cellIfDrawn(rowIndex, columnIndex);
            return drawn[0] != null;
        }, DEFAULT_TIMEOUT_MS, 100, "Waiting for cell [" + rowIndex + "," + columnIndex + "] to be drawn");
        return drawn[0];
    }

    private WebElement cellIfDrawn(int rowIndex, int columnIndex) {
        try {
            int wanted = rowIndex - 1 + rowOffset();
            if (rows.size() <= wanted) {
                return null;
            }
            List<WebElement> cells = rows.get(wanted).getCells();
            return cells.size() < columnIndex ? null : cells.get(columnIndex - 1);
        } catch (RuntimeException beingRedrawn) {
            return null;
        }
    }

    private int rowOffset() {
        return numberedFirstColumn.getLocator().count() == 0 && firstRowLineNumber.getLocator().count() > 0 ? 1 : 0;
    }

    public String getCellText(int rowIndex, int columnIndex) {
        return getCell(rowIndex, columnIndex).getInnerText().trim();
    }

    public List<String> getCellTexts() {
        return allCells.getLocator().allInnerTexts().stream().map(String::trim).toList();
    }

    @SuppressWarnings("unchecked")
    public List<String> getRaisedCellTexts() {
        return (List<String>) allCells.getLocator().evaluateAll(RAISED_CELL_TEXTS);
    }

    public List<String> getColumn(int columnIndex) {
        WaitUtil.waitForListNotEmpty(() -> rows, DEFAULT_TIMEOUT_MS, 250, "Waiting for table rows before getting column " + columnIndex);
        return rows.stream()
                .skip(rowOffset())
                .map(PlaywrightTableRowComponent::getCells)
                .filter(cells -> cells.size() >= columnIndex)
                .map(cells -> cells.get(columnIndex - 1).getInnerText().trim())
                .toList();
    }

    public void doubleClickCell(int rowIndex, int columnIndex) {
        waitUntilSpinnerLoaded();
        getCell(rowIndex, columnIndex).doubleClick();
    }

    public WebElement openCellEditor(int rowIndex, int columnIndex) {
        waitUntilSpinnerLoaded();
        WaitUtil.retryOnException(() -> {
            try {
                doubleClickCell(rowIndex, columnIndex);
            } catch (RuntimeException neverSettles) {
                getCell(rowIndex, columnIndex).doubleClickWhenSettled();
            }
            cellEditor.waitForVisible(2000);
            return true;
        }, 30000, 500, "Activating cell editor for cell [" + rowIndex + "," + columnIndex + "]");

        waitUntilTheEditorIsDrawn();
        return cellEditor;
    }

    public void editCell(int rowIndex, int columnIndex, String text, boolean pressEnter) {
        openCellEditor(rowIndex, columnIndex);
        boolean written = WaitUtil.waitForCondition(() -> {
            if (String.valueOf(cellEditor.getAttribute("class")).contains("ant-select")) {
                WebElement picker = new WebElement(cellEditor, "xpath=.//input", "cellValueInput");
                pickInSelect(picker, text);
                if (pressEnter) {
                    picker.press("Enter");
                }
                return true;
            }
            try {
                cellEditor.press("Control+A");
                cellEditor.press("Delete");
                cellEditor.fill(text);
            } catch (PlaywrightException editorChanged) {
                if (!String.valueOf(editorChanged.getMessage()).contains("Element is not an <input>")) {
                    throw editorChanged;
                }
                return false;
            }
            if (pressEnter) {
                cellEditor.press(keepsWhatIsWritten());
            }
            return true;
        }, 10000, 250, "Writing '" + text + "' into the editor of cell [" + rowIndex + "," + columnIndex + "]");
        if (!written) {
            throw new IllegalStateException("The editor of cell [" + rowIndex + "," + columnIndex
                    + "] took neither the value nor a pick from a list");
        }
        WaitUtil.sleep(250, "Waiting for cell edit to be applied");
    }

    private String keepsWhatIsWritten() {
        return new WebElement(page, "xpath=//textarea[@data-testid='table-cell-input']", "cellLinesEditor").exists()
                ? "Control+Enter"
                : "Enter";
    }

    private void waitUntilTheEditorIsDrawn() {
        String[] last = {null};
        WaitUtil.waitForCondition(() -> {
            String drawn = String.valueOf(cellEditor.getAttribute("class"));
            boolean settled = drawn.equals(last[0]);
            last[0] = drawn;
            return settled;
        }, 5000, 300, "Waiting for the cell editor the cell asks for to be drawn");
    }

    public void editCell(int rowIndex, int columnIndex, String text) {
        editCell(rowIndex, columnIndex, text, true);
    }

    public int getRowIndexHolding(String... values) {
        List<String> wanted = List.of(values);
        for (int row = 1; row <= getRowsCount(); row++) {
            if (getRow(row).getValue().containsAll(wanted)) {
                return row;
            }
        }
        throw new AssertionError("No row of the table holds " + wanted);
    }

    public List<PlaywrightTableRowComponent> getRows() {
        WaitUtil.waitForCondition(() -> !rows.isEmpty(), 3000, 250, "Waiting for table rows to be loaded");
        return rows.subList(rowOffset(), rows.size());
    }

    public int getRowsCount() {
        WaitUtil.waitForListNotEmpty(() -> rows, DEFAULT_TIMEOUT_MS, 250, "Waiting for table rows before counting");
        return rows.size() - rowOffset();
    }

    public PlaywrightTableRowComponent getRow(int rowIndex) {
        PlaywrightTableRowComponent[] drawn = new PlaywrightTableRowComponent[1];
        WaitUtil.requireCondition(() -> {
            try {
                int wanted = rowIndex - 1 + rowOffset();
                if (rows.size() <= wanted) {
                    return false;
                }
                drawn[0] = rows.get(wanted);
                return true;
            } catch (RuntimeException beingRedrawn) {
                return false;
            }
        }, DEFAULT_TIMEOUT_MS, 100, "Waiting for row " + rowIndex + " to be drawn");
        return drawn[0];
    }

    public String getCellHintText(int rowIndex, int columnIndex, String variableName) {
        WebElement named = cellUsage(rowIndex, columnIndex, "*", String.format("contains(normalize-space(.),'%s')", variableName));
        named.hover();
        WebElement hint = new WebElement(page,
                "xpath=//div[@role='tooltip'][contains(@class,'ant-tooltip-container')]"
                        + "[not(ancestor::div[contains(@class,'ant-tooltip-hidden')])]",
                "cellHint");
        hint.waitForVisible(DEFAULT_TIMEOUT_MS);
        WaitUtil.requireCondition(() -> hintSaid(hint).contains(variableName), DEFAULT_TIMEOUT_MS, 200,
                "Waiting for the hint of '" + variableName + "' to be told");
        return hintSaid(hint).trim();
    }

    public WebElement getCellLink(int rowIndex, int columnIndex, String linkText) {
        return cellUsage(rowIndex, columnIndex, "button", String.format("normalize-space(.)='%s'", linkText));
    }

    public List<String> getCellLinkTexts(int rowIndex, int columnIndex) {
        return getCell(rowIndex, columnIndex).getLocator()
                .locator("xpath=.//button" + CELL_USAGE)
                .allInnerTexts().stream().map(String::trim).toList();
    }

    private WebElement cellUsage(int rowIndex, int columnIndex, String tag, String textCondition) {
        return new WebElement(getCell(rowIndex, columnIndex),
                String.format("xpath=(.//%s" + CELL_USAGE + "[%s])[1]", tag, textCondition),
                "cellUsage");
    }

    private String hintSaid(WebElement hint) {
        try {
            return hint.getLocator().first().innerText();
        } catch (RuntimeException beingRedrawn) {
            return "";
        }
    }

    public String getPropertyValue(String propertyName) {
        return propertyValueTemplate.format(propertyName).getText().trim();
    }

    public boolean isPropertyPresent(String propertyName) {
        return propertyValueTemplate.format(propertyName).isVisible();
    }

    public List<String> getHeaders() {
        WebElement headerRow = createScopedElement("xpath=.//thead/tr", "headerRow");
        return headerRow.getLocator().locator("xpath=./th").allTextContents();
    }

    public static class PlaywrightTableRowComponent extends BaseComponent {
        List<WebElement> cells;

        public PlaywrightTableRowComponent() {
            super(DriverPool.getPage());
            initializeElements();
        }

        public PlaywrightTableRowComponent(WebElement rootLocator) {
            super(rootLocator);
            initializeElements();
        }

        private void initializeElements() {
            cells = createScopedElementList("xpath=./td[not(position()=1"
                    + " and ancestor::table[1]/tbody/tr[last()]/td[1][.//span[@data-testid='table-line-number']])]", "cells");
        }

        public  List<WebElement> getCells() {
            WaitUtil.waitForListNotEmpty(() -> cells, 250, 50, "Waiting for table row cells to load");
            return cells;
        }

        public List<String> getValue() {
            return cells.stream().map(e -> e.getInnerText().trim()).toList();
        }
    }
}
