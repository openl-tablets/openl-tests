package domain.ui.webstudio.components.admincomponents;

import configuration.core.ui.WebElement;
import configuration.driver.DriverPool;
import domain.serviceclasses.constants.User;
import domain.ui.webstudio.components.BaseComponent;
import domain.ui.webstudio.pages.mainpages.LoginPage;
import helpers.service.UserService;

public class SystemSettingsPageComponent extends BaseComponent {

    private static final int FIELD_ERROR_SHOWN_MS = 5000;

    private WebElement dispatchingValidationCheckbox;
    private WebElement verifyOnEditCheckbox;
    private WebElement testThreadCountField;
    private WebElement testThreadCountError;
    private WebElement projectHistoryCountField;
    private WebElement detectProjectsByExcelFilesCheckbox;
    private WebElement formatTablesOnSaveCheckbox;
    private WebElement clearAllHistoryBtn;
    private WebElement cancelModalBtn;
    private WebElement applyButton;

    private WebElement dateFormatField;
    private WebElement timeFormatField;

    private WebElement databaseUrlField;
    private WebElement databaseUserField;
    private WebElement databasePasswordField;
    private WebElement databaseMaxPoolSizeField;

    public SystemSettingsPageComponent() {
        super(DriverPool.getPage());
        initializeElements();
    }

    public SystemSettingsPageComponent(WebElement rootLocator) {
        super(rootLocator);
        initializeElements();
    }

    private void initializeElements() {
        dispatchingValidationCheckbox = createScopedElement("xpath=.//*[@id='dispatchingValidationEnabled']", "dispatchingValidationCheckbox");
        verifyOnEditCheckbox = createScopedElement("xpath=.//*[@id='autoCompile']", "verifyOnEditCheckbox");
        testThreadCountField = createScopedElement("xpath=.//*[@id='testRunThreadCount']", "testThreadCountField");
        testThreadCountError = createScopedElement("xpath=.//*[@id='testRunThreadCount']/ancestor::div[contains("
                + "concat(' ', normalize-space(@class), ' '), ' ant-form-item ')][1]"
                + "//div[contains(@class,'ant-form-item-explain-error')]", "testThreadCountError");
        projectHistoryCountField = createScopedElement("xpath=.//*[@id='projectHistoryCount']", "projectHistoryCountField");
        detectProjectsByExcelFilesCheckbox = createScopedElement("xpath=.//*[@id='detectProjectsByExcelFiles']", "detectProjectsByExcelFilesCheckbox");
        formatTablesOnSaveCheckbox = createScopedElement("xpath=.//*[@id='formatTablesOnSave']", "formatTablesOnSaveCheckbox");
        clearAllHistoryBtn = createScopedElement("xpath=.//button[./span[text()='Clear All History']]", "clearAllHistoryBtn");
        cancelModalBtn = new WebElement(page, "xpath=//div[contains(@class,'ant-modal-container')]//button[./span[contains(text(),'Cancel')]]", "cancelModalBtn");
        applyButton = createScopedElement("xpath=.//button[./span[text()='Apply Changes'] or ./span[text()='Apply']]", "applyButton");

        dateFormatField = createScopedElement("xpath=.//input[@id='datePattern']", "dateFormatField");
        timeFormatField = createScopedElement("xpath=.//input[@id='timeFormat']", "timeFormatField");

        databaseUrlField = createScopedElement("xpath=.//input[@id='db_url']", "databaseUrlField");
        databaseUserField = createScopedElement("xpath=.//input[@id='db_user']", "databaseUserField");
        databasePasswordField = createScopedElement("xpath=.//input[@id='db_password']", "databasePasswordField");
        databaseMaxPoolSizeField = createScopedElement("xpath=.//input[@id='db_maximumPoolSize']", "databaseMaxPoolSizeField");
    }

    public void setDispatchingValidation(boolean enable) {
        if (enable != dispatchingValidationCheckbox.isChecked()) {
            dispatchingValidationCheckbox.click();
        }
    }

    public void setVerifyOnEdit(boolean enable) {
        if (enable != verifyOnEditCheckbox.isChecked()) {
            verifyOnEditCheckbox.click();
        }
    }

    public void setTestThreadCount(String value) {
        testThreadCountField.fill(value);
    }

    public String getTestThreadCount() {
        return testThreadCountField.getAttribute("value");
    }

    public String getTestThreadCountError() {
        return testThreadCountError.isVisible(FIELD_ERROR_SHOWN_MS) ? testThreadCountError.getText().trim() : "";
    }

    public void waitForTestThreadCountErrorHidden() {
        testThreadCountError.waitForHidden(FIELD_ERROR_SHOWN_MS);
    }

    public void clickApplyButton() {
        applyButton.click();
        getModalOkBtn().waitForVisible().click();
    }

    public void applySettingsAndRelogin(User user) {
        clickApplyButton();
        new LoginPage().login(UserService.getUser(user));
    }

    public void setDateFormat(String format) {
        dateFormatField.fill(format);
    }

    public String getDateFormat() {
        return dateFormatField.getAttribute("value");
    }

    public void setTimeFormat(String format) {
        timeFormatField.fill(format);
    }

    public String getTimeFormat() {
        return timeFormatField.getAttribute("value");
    }

    public String getDatabaseUrl() {
        return databaseUrlField.getAttribute("value");
    }

    public void setDatabaseUrl(String url) {
        databaseUrlField.fill(url);
    }

    public String getDatabaseUser() {
        return databaseUserField.getAttribute("value");
    }

    public void setDatabaseUser(String user) {
        databaseUserField.fill(user);
    }

    public void setDatabasePassword(String password) {
        databasePasswordField.fill(password);
    }

    public int getDatabaseMaxPoolSize() {
        String value = databaseMaxPoolSizeField.getAttribute("value");
        return value != null && !value.isEmpty() ? Integer.parseInt(value) : 50;
    }

    public void setDatabaseMaxPoolSize(int size) {
        databaseMaxPoolSizeField.fill(String.valueOf(size));
    }

    public void setProjectHistoryCount(String value) {
        projectHistoryCountField.clear();
        projectHistoryCountField.fill(value);
    }

    public String getProjectHistoryCount() {
        return projectHistoryCountField.getAttribute("value");
    }

    public void clearAllHistory() {
        clearAllHistoryBtn.click();
        getModalOkBtn().waitForVisible().click();
    }

    public void cancelClearAllHistory() {
        clearAllHistoryBtn.click();
        cancelModalBtn.waitForVisible().click();
    }

    public void setDetectProjectsByExcelFiles(boolean enable) {
        if (enable != detectProjectsByExcelFilesCheckbox.isChecked()) {
            detectProjectsByExcelFilesCheckbox.click();
        }
    }

    public boolean isDetectProjectsByExcelFilesEnabled() {
        return detectProjectsByExcelFilesCheckbox.isChecked();
    }

    public void setFormatTablesOnSave(boolean enable) {
        if (enable != formatTablesOnSaveCheckbox.isChecked()) {
            formatTablesOnSaveCheckbox.click();
        }
    }
}
