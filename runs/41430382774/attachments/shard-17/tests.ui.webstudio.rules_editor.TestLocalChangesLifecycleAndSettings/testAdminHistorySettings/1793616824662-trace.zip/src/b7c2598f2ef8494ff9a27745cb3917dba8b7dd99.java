package tests.ui.webstudio.rules_editor;

import configuration.annotations.Description;
import configuration.annotations.TestCaseId;
import configuration.annotations.AppContainerConfig;
import configuration.appcontainer.AppContainerStartParameters;
import domain.serviceclasses.constants.User;
import domain.ui.webstudio.components.admincomponents.SystemSettingsPageComponent;
import domain.ui.webstudio.components.editortabcomponents.ChangesDialogComponent;
import domain.ui.webstudio.components.editortabcomponents.CompareLocalChangesDialogComponent;
import domain.ui.webstudio.components.common.TabSwitcherComponent;
import domain.ui.webstudio.components.editortabcomponents.leftmenu.EditorLeftRulesTreeComponent;
import domain.ui.webstudio.pages.mainpages.AdminPage;
import domain.ui.webstudio.pages.mainpages.EditorPage;
import domain.ui.webstudio.pages.mainpages.RepositoryPage;
import helpers.service.WorkflowService;
import org.testng.annotations.Test;
import tests.BaseTest;

import static org.assertj.core.api.Assertions.assertThat;
import static domain.ui.webstudio.components.editortabcomponents.leftmenu.TableTypeFolders.DECISION;

public class TestLocalChangesLifecycleAndSettings extends BaseTest {

    @Test
    @TestCaseId("IPBQA-30730")
    @Description("Steps 14-15: Close/reopen project discards local changes and clears history; new edit after reopen creates fresh Local Changes (1).")
    @AppContainerConfig(startParams = AppContainerStartParameters.DEFAULT_STUDIO_PARAMS)
    public void testProjectLifecycleClearsHistory() {
        String projectName = WorkflowService.loginCreateProjectFromTemplate(User.ADMIN, "Sample Project");
        EditorPage editorPage = new EditorPage();

        editorPage.getEditorLeftProjectModuleSelectorComponent().selectModule(projectName, "Main");
        editorPage.getEditorLeftRulesTreeComponent()
                .setViewFilter(EditorLeftRulesTreeComponent.FilterOptions.BY_TYPE)
                .expandFolderInTree(DECISION)
                .selectItemInFolder(DECISION, "Hello");

        editorPage.getEditorToolbarPanelComponent().getEditTableBtn().click();
        editorPage.getCenterTable().editCell(6, 4, "Good Morning1");
        editorPage.getEditorTableActionsPanelComponent().clickSaveChanges();

        RepositoryPage repositoryPage = editorPage.getTabSwitcherComponent().selectTab(TabSwitcherComponent.TabName.REPOSITORY);
        repositoryPage.closeProject(projectName);
        repositoryPage.waitUntilAppIdle();

        assertThat(repositoryPage.openProjectDetail(projectName).openFilesTab().isFolderPresent(".history"))
                .as(".history folder should not be visible in repository after project close")
                .isFalse();

        repositoryPage.openProjectsList().openProject(projectName);
        repositoryPage.waitUntilSpinnerLoaded();

        editorPage = new EditorPage();
        editorPage.getEditorLeftProjectModuleSelectorComponent().selectModule(projectName, "Main");
        editorPage.getEditorLeftRulesTreeComponent()
                .setViewFilter(EditorLeftRulesTreeComponent.FilterOptions.BY_TYPE)
                .expandFolderInTree(DECISION)
                .selectItemInFolder(DECISION, "Hello");

        assertThat(editorPage.getCenterTable().getCellText(6, 4))
                .as("Cell value should be reverted to original after close and reopen")
                .isEqualTo("Good Morning");

        ChangesDialogComponent changesDialog = editorPage.getEditorToolbarPanelComponent()
                .clickMore()
                .clickChanges();
        assertThat(changesDialog.getNoChangesMessage())
                .as("No history should exist after close and reopen")
                .isEqualTo("No changes in history");

        editorPage.getEditorLeftRulesTreeComponent()
                .expandFolderInTree(DECISION)
                .selectItemInFolder(DECISION, "Hello");

        editorPage.getEditorToolbarPanelComponent().getEditTableBtn().click();
        editorPage.getCenterTable().editCell(7, 4, "Good Afternoon1");
        editorPage.getEditorTableActionsPanelComponent().clickSaveChanges();

        changesDialog = editorPage.getEditorToolbarPanelComponent()
                .clickMore()
                .clickChanges();
        assertThat(changesDialog.getChangesTitle())
                .as("After close/reopen, new edit should create fresh Local Changes (1)")
                .isEqualTo("Local Changes");
        assertThat(changesDialog.getChangesCount())
                .as("After close/reopen, new edit should create fresh Local Changes (1)")
                .isEqualTo(1);
        assertThat(changesDialog.getRowCount())
                .as("Should be 2 rows in fresh history after close/reopen")
                .isEqualTo(2);
        assertThat(changesDialog.getCompareCheckboxValue(1))
                .as("Checkbox at row 1 should be auto-checked (current version)")
                .isTrue();
    }

    @Test
    @TestCaseId("IPBQA-30730")
    @Description("Steps 17-19 and cancel: Cancel Clear All History preserves history; Clear All History removes all entries; historyCount=0 disables tracking; historyCount=10 re-enables tracking with compare dialog.")
    @AppContainerConfig(startParams = AppContainerStartParameters.DEFAULT_STUDIO_PARAMS)
    public void testAdminHistorySettings() {
        String projectName = WorkflowService.loginCreateProjectFromTemplate(User.ADMIN, "Sample Project");
        EditorPage editorPage = new EditorPage();

        editorPage.getEditorLeftProjectModuleSelectorComponent().selectModule(projectName, "Main");
        editorPage.getEditorLeftRulesTreeComponent()
                .setViewFilter(EditorLeftRulesTreeComponent.FilterOptions.BY_TYPE)
                .expandFolderInTree(DECISION)
                .selectItemInFolder(DECISION, "Hello");

        editorPage.getEditorToolbarPanelComponent().getEditTableBtn().click();
        editorPage.getCenterTable().editCell(6, 4, "Good Morning1");
        editorPage.getEditorTableActionsPanelComponent().clickSaveChanges();

        AdminPage adminPage = editorPage.openUserMenu().navigateToAdministration();
        SystemSettingsPageComponent systemSettings = adminPage.navigateToSystemSettingsPage();
        systemSettings.cancelClearAllHistory();
        new EditorPage();

        editorPage = new EditorPage();
        editorPage.getEditorLeftProjectModuleSelectorComponent().selectModule(projectName, "Main");
        editorPage.getEditorLeftRulesTreeComponent()
                .setViewFilter(EditorLeftRulesTreeComponent.FilterOptions.BY_TYPE)
                .expandFolderInTree(DECISION)
                .selectItemInFolder(DECISION, "Hello");

        ChangesDialogComponent changesDialog = editorPage.getEditorToolbarPanelComponent()
                .clickMore()
                .clickChanges();
        assertThat(changesDialog.getChangesTitle())
                .as("Cancel should not clear local change history")
                .isEqualTo("Local Changes");
        assertThat(changesDialog.getChangesCount())
                .as("Cancel should not clear local change history")
                .isEqualTo(1);
        assertThat(changesDialog.getRowCount())
                .as("Should still have 2 rows after cancel")
                .isEqualTo(2);

        adminPage = editorPage.openUserMenu().navigateToAdministration();
        systemSettings = adminPage.navigateToSystemSettingsPage();
        systemSettings.clearAllHistory();
        new EditorPage();

        editorPage = new EditorPage();
        editorPage.getEditorLeftProjectModuleSelectorComponent().selectModule(projectName, "Main");
        editorPage.getEditorLeftRulesTreeComponent()
                .setViewFilter(EditorLeftRulesTreeComponent.FilterOptions.BY_TYPE)
                .expandFolderInTree(DECISION)
                .selectItemInFolder(DECISION, "Hello");

        changesDialog = editorPage.getEditorToolbarPanelComponent()
                .clickMore()
                .clickChanges();
        assertThat(changesDialog.getNoChangesMessage())
                .as("Clear All History should remove all local change history")
                .isEqualTo("No changes in history");

        adminPage = editorPage.openUserMenu().navigateToAdministration();
        systemSettings = adminPage.navigateToSystemSettingsPage();
        systemSettings.setProjectHistoryCount("0");
        systemSettings.applySettingsAndRelogin(User.ADMIN);

        new EditorPage();
        editorPage.getEditorLeftProjectModuleSelectorComponent().selectModule(projectName, "Main");
        editorPage.getEditorLeftRulesTreeComponent()
                .setViewFilter(EditorLeftRulesTreeComponent.FilterOptions.BY_TYPE)
                .expandFolderInTree(DECISION)
                .selectItemInFolder(DECISION, "Hello");

        editorPage.getEditorToolbarPanelComponent().getEditTableBtn().click();
        editorPage.getCenterTable().editCell(7, 4, "Good Afternoon1");
        editorPage.getEditorTableActionsPanelComponent().clickSaveChanges();

        changesDialog = editorPage.getEditorToolbarPanelComponent()
                .clickMore()
                .clickChanges();
        assertThat(changesDialog.getNoChangesMessage())
                .as("historyCount=0 should disable local change tracking")
                .isEqualTo("No changes in history");

        adminPage = editorPage.openUserMenu().navigateToAdministration();
        systemSettings = adminPage.navigateToSystemSettingsPage();
        systemSettings.setProjectHistoryCount("10");
        systemSettings.applySettingsAndRelogin(User.ADMIN);

        new EditorPage();
        editorPage.getEditorLeftProjectModuleSelectorComponent().selectModule(projectName, "Main");
        editorPage.getEditorLeftRulesTreeComponent()
                .setViewFilter(EditorLeftRulesTreeComponent.FilterOptions.BY_TYPE)
                .expandFolderInTree(DECISION)
                .selectItemInFolder(DECISION, "Hello");

        editorPage.getEditorToolbarPanelComponent().getEditTableBtn().click();
        editorPage.getCenterTable().editCell(8, 4, "Good Evening3");
        editorPage.getEditorTableActionsPanelComponent().clickSaveChanges();

        changesDialog = editorPage.getEditorToolbarPanelComponent()
                .clickMore()
                .clickChanges();
        assertThat(changesDialog.getChangesTitle())
                .as("historyCount=10 should re-enable local change tracking")
                .isEqualTo("Local Changes");
        assertThat(changesDialog.getChangesCount())
                .as("historyCount=10 should re-enable local change tracking")
                .isEqualTo(1);

        changesDialog.setCompareCheckbox(1, true);
        changesDialog.setCompareCheckbox(2, true);
        CompareLocalChangesDialogComponent compareDialog = changesDialog.clickCompare();
        compareDialog.waitForDialogToAppear();
        compareDialog.openTreeNode("Rules");
        compareDialog.clickTreeNode("Rules String Hello (Integer hour)");

        assertThat(compareDialog.isDifferenceShown(2, "Good Evening3"))
                .as("The value the edit wrote must be shown as a difference in the version that carries it")
                .isTrue();
        compareDialog.close();
    }
}
