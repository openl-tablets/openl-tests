package domain.ui.webstudio.components.editortabcomponents.toolbar;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import configuration.core.ui.WebElement;
import domain.ui.webstudio.pages.BasePage;
import helpers.utils.WaitUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

public class TraceWindowComponent extends BasePage implements ITraceWindow {

    private static final Logger LOGGER = LogManager.getLogger(TraceWindowComponent.class);

    private static final int CALL_TREE_TIMEOUT_MS = DEFAULT_TIMEOUT_MS * 3;
    private static final int DETAILS_TIMEOUT_MS = 5000;
    private static final String TREE_NODE = "//*[@data-testid='trace-tree']//div[starts-with(@data-testid,'tree-frame-') or starts-with(@data-testid,'tree-step-')]";

    private final List<WebElement> callTreeNodes;
    private final WebElement callTreeNodeTemplate;
    private final WebElement status;
    private final WebElement tracedTable;
    private final WebElement details;
    private final WebElement nodeDetailsError;
    private final WebElement resumeBtn;
    private final WebElement stepOverBtn;
    private final WebElement debugToolbar;
    private final WebElement detailedTraceToggle;
    private final WebElement simpleTree;
    private final WebElement breakOnFireCheckbox;
    private final WebElement breakOnRuleSelect;
    private final WebElement breakOnRuleOption;
    private final WebElement watchInput;
    private final WebElement watchAddButton;
    private final WebElement watchPanel;
    private final WebElement rerunBtn;
    private WebElement decisionPanel;

    public TraceWindowComponent(Page tracePage) {
        super(tracePage);
        callTreeNodes = createElementList("xpath=" + TREE_NODE, "callTreeNodes");
        callTreeNodeTemplate = new WebElement(tracePage, "xpath=(" + TREE_NODE + ")[%d]", "callTreeNode");
        status = new WebElement(tracePage, "xpath=//*[@data-testid='debug-status']", "debugStatus");
        tracedTable = new WebElement(tracePage, "xpath=//*[@data-testid='trace-table']", "tracedTable");
        details = new WebElement(tracePage, "xpath=//*[@data-testid='debug-details']", "debugDetails");
        nodeDetailsError = new WebElement(tracePage, "xpath=//*[@data-testid='debug-details' and contains(.,'Failed to load node details')]", "nodeDetailsError");
        resumeBtn = new WebElement(tracePage, "xpath=//*[@data-testid='debug-resume']", "resumeBtn");
        stepOverBtn = new WebElement(tracePage, "xpath=//*[@data-testid='debug-step-over']", "stepOverBtn");
        debugToolbar = new WebElement(tracePage, "xpath=//*[@data-testid='debug-toolbar']", "debugToolbar");
        detailedTraceToggle = new WebElement(tracePage, "xpath=//*[@data-testid='trace-detailed']", "detailedTraceToggle");
        simpleTree = new WebElement(tracePage, "xpath=//*[@data-testid='simple-tree']", "simpleTree");
        breakOnFireCheckbox = new WebElement(tracePage,
                "xpath=//*[@data-testid='decision-break-on-fire']//input | //input[@data-testid='decision-break-on-fire']",
                "breakOnFireCheckbox");
        breakOnRuleSelect = new WebElement(tracePage, "xpath=//*[@data-testid='decision-rule-select']", "breakOnRuleSelect");
        breakOnRuleOption = new WebElement(tracePage,
                "xpath=//div[contains(@class,'ant-select-dropdown')][not(contains(@class,'ant-select-dropdown-hidden'))]//div[contains(@class,'ant-select-item-option')][@title='%s' or .//*[normalize-space()='%s']]",
                "breakOnRuleOption");
        watchInput = new WebElement(tracePage,
                "xpath=//*[@data-testid='watch-add']//input | //input[@data-testid='watch-add']", "watchInput");
        watchAddButton = new WebElement(tracePage, "xpath=//*[@data-testid='watch-add-button']", "watchAddButton");
        watchPanel = new WebElement(tracePage, "xpath=//*[@data-testid='watch-panel']", "watchPanel");
        rerunBtn = new WebElement(tracePage, "xpath=//*[@data-testid='debug-rerun']", "rerunBtn");
        decisionPanel = new WebElement(tracePage, "xpath=//*[@data-testid='decision-panel']", "decisionPanel");
    }

    @Override
    public String getStatus() {
        return status.getText().trim();
    }

    @Override
    public List<String> getCallTreeTitles() {
        boolean loaded = WaitUtil.waitForCondition(() -> !callTreeNodes.isEmpty(), CALL_TREE_TIMEOUT_MS, 200,
                "Waiting for trace call-tree nodes to appear");
        if (!loaded) {
            LOGGER.warn("Trace call tree is still empty after {} ms, debugger status: '{}'", CALL_TREE_TIMEOUT_MS,
                    status.exists() ? status.getText().trim() : "<none>");
        }
        return callTreeNodes.stream().map(n -> n.getText().replaceAll("\\s+", " ").trim()).toList();
    }

    @Override
    public ITraceWindow selectTreeNode(int position) {
        callTreeNodeTemplate.format(position + 1).click();
        WaitUtil.waitForCondition(() -> details.isVisible(1000), 5000, 200, "Waiting for node details to load");
        return this;
    }

    @Override
    public ITraceWindow stepOver() {
        stepOverBtn.click();
        return this;
    }

    @Override
    public ITraceWindow resume() {
        resumeBtn.click();
        return this;
    }

    @Override
    public String getDetailsText() {
        return details.getText();
    }

    @Override
    public String getTracedTableText() {
        return tracedTable.getText();
    }

    @Override
    public boolean isNodeDetailsErrorDisplayed(int timeoutInMillis) {
        return nodeDetailsError.isVisible(timeoutInMillis);
    }

    @Override
    public boolean areDetailsDisplayed(int timeoutInMillis) {
        return details.isVisible(timeoutInMillis);
    }

    @Override
    public boolean isDebugToolbarShown(int timeoutInMillis) {
        return debugToolbar.isVisible(timeoutInMillis);
    }

    @Override
    public boolean isBusinessToggleShown(int timeoutInMillis) {
        return detailedTraceToggle.isVisible(timeoutInMillis);
    }

    @Override
    public ITraceWindow toggleDetailedTrace() {
        detailedTraceToggle.click();
        return this;
    }

    @Override
    public String getSimpleTreeText() {
        return simpleTree.waitForVisible(DEFAULT_TIMEOUT_MS).getText().replaceAll("\\s+", " ").trim();
    }

    @Override
    public ITraceWindow expandSimpleStep(String step) {
        getPage().locator("xpath=//*[@data-testid='simple-toggle-" + simpleStepKey(step) + "']").click();
        WaitUtil.requireCondition(() -> getSimpleCallsCount(step) > 0, CALL_TREE_TIMEOUT_MS, 250,
                "Waiting for the calls of the step " + step + " to be listed");
        return this;
    }

    @Override
    public int getSimpleCallsCount(String step) {
        return getPage().locator("xpath=//*[starts-with(@data-testid,'simple-node-" + simpleStepKey(step) + "#')]").count();
    }

    @Override
    public String getSimpleMoreCallsText(String step) {
        Locator more = simpleMoreCalls(step);
        return more.count() == 0 ? "" : more.innerText().trim();
    }

    @Override
    public ITraceWindow showMoreSimpleCalls(String step) {
        int shown = getSimpleCallsCount(step);
        simpleMoreCalls(step).click();
        WaitUtil.requireCondition(() -> getSimpleCallsCount(step) > shown, CALL_TREE_TIMEOUT_MS, 250,
                "Waiting for the further calls of the step " + step + " to be listed");
        return this;
    }

    @Override
    public ITraceWindow selectSimpleRow(int position) {
        simpleRows().nth(position).click();
        return waitForDetailsOfSelectedRow();
    }

    @Override
    public ITraceWindow selectLastSimpleRow() {
        int[] rowsSeen = {-1};
        WaitUtil.requireCondition(() -> {
            int rows = simpleRows().count();
            boolean settled = rows > 0 && rows == rowsSeen[0];
            rowsSeen[0] = rows;
            return settled;
        }, CALL_TREE_TIMEOUT_MS, 1000, "Waiting for the call tree to stop growing");
        Locator row = simpleRows().last();
        row.scrollIntoViewIfNeeded();
        row.click();
        return waitForDetailsOfSelectedRow();
    }

    @Override
    public boolean isSimpleRowFailed(int position) {
        return "true".equals(simpleRows().nth(position).getAttribute("data-failed"));
    }

    @Override
    public String getSimpleRowText(int position) {
        return normalized(simpleRows().nth(position).innerText());
    }

    @Override
    public ITraceWindow loadFirstDetailsValue() {
        getPage().locator("xpath=//*[@data-testid='debug-details']//button[starts-with(@data-testid,'load-')]").first().click();
        return this;
    }

    @Override
    public ITraceWindow waitForDetailsToContain(String expectedText) {
        WaitUtil.requireCondition(() -> normalized(getDetailsText()).contains(expectedText), CALL_TREE_TIMEOUT_MS, 250,
                "Waiting for the details to show '" + expectedText + "'");
        return this;
    }

    private ITraceWindow waitForDetailsOfSelectedRow() {
        WaitUtil.requireCondition(() -> details.isVisible(1000), DETAILS_TIMEOUT_MS, 200, "Waiting for the details of the selected row");
        return this;
    }

    private static String normalized(String text) {
        return text.replaceAll("\\s+", " ").trim();
    }

    private Locator simpleRows() {
        simpleTree.waitForVisible(CALL_TREE_TIMEOUT_MS);
        return getPage().locator("xpath=//*[@data-testid='simple-tree']//*[starts-with(@data-testid,'simple-node-') or starts-with(@data-testid,'simple-step-')]");
    }

    private Locator simpleMoreCalls(String step) {
        return getPage().locator("xpath=//*[@data-testid='simple-more-" + simpleStepKey(step) + "/more']");
    }

    private String simpleStepKey(String step) {
        simpleTree.waitForVisible(DEFAULT_TIMEOUT_MS);
        Locator stepRow = getPage().locator("xpath=//*[starts-with(@data-testid,'simple-step-')]"
                + "[starts-with(normalize-space(),'" + step + " ')]");
        return stepRow.getAttribute("data-testid").substring("simple-step-".length());
    }

    @Override
    public ITraceWindow setBreakWhenRuleFires() {
        breakOnFireCheckbox.checkEvenIfHidden();
        return this;
    }

    @Override
    public ITraceWindow pickBreakOnRule(String ruleName) {
        breakOnRuleSelect.click();
        breakOnRuleOption.format(ruleName, ruleName).waitForVisible(DEFAULT_TIMEOUT_MS).click();
        page.keyboard().press("Escape");
        return this;
    }

    @Override
    public ITraceWindow addWatch(String expression) {
        watchInput.fill(expression);
        watchAddButton.click();
        return this;
    }

    @Override
    public String getWatchPanelText() {
        return watchPanel.getText().replaceAll("\\s+", " ").trim();
    }

    @Override
    public ITraceWindow clickRerun() {
        rerunBtn.click();
        return this;
    }

    @Override
    public ITraceWindow waitForStatus(String expectedStatus, int timeoutInMillis) {
        WaitUtil.waitForCondition(() -> getStatus().contains(expectedStatus), timeoutInMillis, 250,
                "Waiting for the debugger status '" + expectedStatus + "'");
        return this;
    }

    @Override
    public String getDecisionPanelText() {
        return decisionPanel.getText().replaceAll("\\s+", " ").trim();
    }

    @Override
    public ITraceWindow waitForDecisionPanelToContain(String expectedText, int timeoutInMillis) {
        WaitUtil.waitForCondition(() -> getDecisionPanelText().contains(expectedText), timeoutInMillis, 250,
                "Waiting for the decision panel to report '" + expectedText + "'");
        return this;
    }

    @Override
    public void close() {
        if (getPage() != null && !getPage().isClosed()) {
            LOGGER.debug("Closing trace popup window");
            getPage().close();
        }
    }
}
