package tests.ui.webstudio.rules_editor;

import configuration.annotations.Description;
import configuration.annotations.TestCaseId;
import configuration.annotations.AppContainerConfig;
import configuration.appcontainer.AppContainerStartParameters;
import domain.serviceclasses.constants.User;
import domain.ui.webstudio.components.editortabcomponents.ChangesDialogComponent;
import domain.ui.webstudio.components.editortabcomponents.CompareLocalChangesDialogComponent;
import domain.ui.webstudio.components.editortabcomponents.EditorRevisionsTabComponent;
import domain.ui.webstudio.components.common.TabSwitcherComponent;
import domain.ui.webstudio.components.editortabcomponents.leftmenu.EditorLeftRulesTreeComponent;
import domain.ui.webstudio.pages.mainpages.EditorPage;
import domain.ui.webstudio.pages.mainpages.RepositoryPage;
import helpers.service.WorkflowService;
import org.testng.annotations.Test;
import tests.BaseTest;

import static org.assertj.core.api.Assertions.assertThat;
import static domain.ui.webstudio.components.editortabcomponents.leftmenu.TableTypeFolders.DECISION;

public class TestLocalChangesCoreMechanics extends BaseTest {

    @Test
    @TestCaseId("IPBQA-30730")
    @Description("Steps 1-8.1: Fresh state shows no history; undo does not create history; single/double edits create Local Changes with compare dialog; .history absent in repo during local edits; restore to row 2 reverts only the second edit.")
    @AppContainerConfig(startParams = AppContainerStartParameters.DEFAULT_STUDIO_PARAMS)
    public void testCoreHistoryMechanics() {
        String projectName = WorkflowService.loginCreateProjectFromTemplate(User.ADMIN, "Sample Project");
        EditorPage editorPage = new EditorPage();

        editorPage.getEditorLeftProjectModuleSelectorComponent().selectModule(projectName, "Main");
        editorPage.getEditorLeftRulesTreeComponent()
                .setViewFilter(EditorLeftRulesTreeComponent.FilterOptions.BY_TYPE)
                .expandFolderInTree(DECISION)
                .selectItemInFolder(DECISION, "Hello");

        ChangesDialogComponent changesDialog = editorPage.getEditorToolbarPanelComponent()
                .clickMore()
                .clickChanges();
        assertThat(changesDialog.getNoChangesMessage())
                .as("Fresh project should show no changes message")
                .isEqualTo("No changes in history");

        editorPage.getEditorLeftRulesTreeComponent()
                .expandFolderInTree(DECISION)
                .selectItemInFolder(DECISION, "Hello");

        editorPage.getEditorToolbarPanelComponent().getEditTableBtn().click();
        editorPage.getCenterTable().editCell(6, 4, "Good Morning1");
        editorPage.getEditorTableActionsPanelComponent().undoClickChanges();

        changesDialog = editorPage.getEditorToolbarPanelComponent()
                .clickMore()
                .clickChanges();
        assertThat(changesDialog.getNoChangesMessage())
                .as("Undone edit should not create a history entry")
                .isEqualTo("No changes in history");

        editorPage.getEditorLeftRulesTreeComponent()
                .expandFolderInTree(DECISION)
                .selectItemInFolder(DECISION, "Hello");

        editorPage.getEditorToolbarPanelComponent().getEditTableBtn().click();
        editorPage.getCenterTable().editCell(6, 4, "Good Morning1");
        editorPage.getEditorTableActionsPanelComponent().clickSaveChanges();

        changesDialog = editorPage.getEditorToolbarPanelComponent()
                .clickMore()
                .clickChanges();
        assertThat(changesDialog.getChangesTitle())
                .as("Changes title should show 1 local change")
                .isEqualTo("Local Changes");
        assertThat(changesDialog.getChangesCount())
                .as("Changes title should show 1 local change")
                .isEqualTo(1);
        assertThat(changesDialog.getRowCount())
                .as("Should be 2 rows in history (current + previous)")
                .isEqualTo(2);
        assertThat(changesDialog.getCompareCheckboxValue(1))
                .as("Checkbox at row 1 should be auto-checked (current version)")
                .isTrue();

        changesDialog.setCompareCheckbox(1, true);
        changesDialog.setCompareCheckbox(2, true);
        CompareLocalChangesDialogComponent compareDialog = changesDialog.clickCompare();
        compareDialog.waitForDialogToAppear();
        compareDialog.openTreeNode("Rules");
        compareDialog.clickTreeNode("Rules String Hello (Integer hour)");

        assertThat(compareDialog.isDifferenceShown(1, "Good Morning"))
                .as("The older state should show 'Good Morning' as what differs after the single edit")
                .isTrue();
        assertThat(compareDialog.isDifferenceShown(2, "Good Morning1"))
                .as("The newer state should show 'Good Morning1' as what differs after the single edit")
                .isTrue();
        compareDialog.close();

        editorPage.getEditorLeftRulesTreeComponent()
                .expandFolderInTree(DECISION)
                .selectItemInFolder(DECISION, "Hello");

        editorPage.getEditorToolbarPanelComponent().getEditTableBtn().click();
        editorPage.getCenterTable().editCell(7, 4, "Good Afternoon1");
        editorPage.getEditorTableActionsPanelComponent().clickSaveChanges();

        changesDialog = editorPage.getEditorToolbarPanelComponent()
                .clickMore()
                .clickChanges();
        assertThat(changesDialog.getChangesTitle())
                .as("Changes title should show 2 local changes")
                .isEqualTo("Local Changes");
        assertThat(changesDialog.getChangesCount())
                .as("Changes title should show 2 local changes")
                .isEqualTo(2);
        assertThat(changesDialog.getRowCount())
                .as("Should be 3 rows in history")
                .isEqualTo(3);
        assertThat(changesDialog.getCompareCheckboxValue(1))
                .as("Checkbox at row 1 should be auto-checked (current version)")
                .isTrue();

        changesDialog.setCompareCheckbox(1, true);
        changesDialog.setCompareCheckbox(2, true);
        compareDialog = changesDialog.clickCompare();
        compareDialog.waitForDialogToAppear();
        compareDialog.openTreeNode("Rules");
        compareDialog.clickTreeNode("Rules String Hello (Integer hour)");

        assertThat(compareDialog.isDifferenceShown(1, "Good Afternoon"))
                .as("The older state should show 'Good Afternoon' as what differs after the second edit")
                .isTrue();
        assertThat(compareDialog.isDifferenceShown(2, "Good Afternoon1"))
                .as("The newer state should show 'Good Afternoon1' as what differs after the second edit")
                .isTrue();
        compareDialog.close();

        RepositoryPage repositoryPage = editorPage.getTabSwitcherComponent().selectTab(TabSwitcherComponent.TabName.REPOSITORY);
        assertThat(repositoryPage.openProjectDetail(projectName).openFilesTab().isFolderPresent(".history"))
                .as(".history folder should not be visible in repository while local changes exist (not committed)")
                .isFalse();

        editorPage = new EditorPage();
        editorPage.getEditorLeftProjectModuleSelectorComponent().selectModule(projectName, "Main");
        editorPage.getEditorLeftRulesTreeComponent()
                .setViewFilter(EditorLeftRulesTreeComponent.FilterOptions.BY_TYPE)
                .expandFolderInTree(DECISION)
                .selectItemInFolder(DECISION, "Hello");

        editorPage.getEditorToolbarPanelComponent().clickMore().clickChanges();
        changesDialog.clickRestoreAtRow(2);
        editorPage.waitUntilSpinnerLoaded();

        editorPage.getEditorLeftRulesTreeComponent()
                .setViewFilter(EditorLeftRulesTreeComponent.FilterOptions.BY_TYPE)
                .expandFolderInTree(DECISION)
                .selectItemInFolder(DECISION, "Hello");

        assertThat(editorPage.getCenterTable().getCellText(6, 4))
                .as("Cell (6,4) should still have the first edit value after restoring to row 2")
                .isEqualTo("Good Morning1");
        assertThat(editorPage.getCenterTable().getCellText(7, 4))
                .as("Cell (7,4) should be reverted to original value after restoring to row 2")
                .isEqualTo("Good Afternoon");
    }

    @Test
    @TestCaseId("IPBQA-30730")
    @Description("Steps 9-13: Three edits and restore to row 2; saving clears local history and creates 2 revisions; new edit after save creates fresh Local Changes (1).")
    @AppContainerConfig(startParams = AppContainerStartParameters.DEFAULT_STUDIO_PARAMS)
    public void testExtendedRestoreAndSave() {
        String projectName = WorkflowService.loginCreateProjectFromTemplate(User.ADMIN, "Sample Project");
        EditorPage editorPage = new EditorPage();

        editorPage.getEditorLeftProjectModuleSelectorComponent().selectModule(projectName, "Main");
        editorPage.getEditorLeftRulesTreeComponent()
                .setViewFilter(EditorLeftRulesTreeComponent.FilterOptions.BY_TYPE)
                .expandFolderInTree(DECISION)
                .selectItemInFolder(DECISION, "Hello");

        editorPage.getEditorToolbarPanelComponent().getEditTableBtn().click();
        editorPage.getCenterTable().editCell(6, 4, "Good Morning1");
        editorPage.getEditorTableActionsPanelComponent().clickSaveChanges();

        editorPage.getEditorToolbarPanelComponent().getEditTableBtn().click();
        editorPage.getCenterTable().editCell(7, 4, "Good Afternoon1");
        editorPage.getEditorTableActionsPanelComponent().clickSaveChanges();

        editorPage.getEditorToolbarPanelComponent().getEditTableBtn().click();
        editorPage.getCenterTable().editCell(8, 4, "Good Evening3");
        editorPage.getEditorTableActionsPanelComponent().clickSaveChanges();

        ChangesDialogComponent changesDialog = editorPage.getEditorToolbarPanelComponent()
                .clickMore()
                .clickChanges();
        assertThat(changesDialog.getChangesTitle())
                .as("Changes title should show 3 local changes")
                .isEqualTo("Local Changes");
        assertThat(changesDialog.getChangesCount())
                .as("Changes title should show 3 local changes")
                .isEqualTo(3);
        assertThat(changesDialog.getRowCount())
                .as("Should be 4 rows in history")
                .isEqualTo(4);

        changesDialog.clickRestoreAtRow(2);
        editorPage.waitUntilSpinnerLoaded();

        editorPage.getEditorLeftRulesTreeComponent()
                .setViewFilter(EditorLeftRulesTreeComponent.FilterOptions.BY_TYPE)
                .expandFolderInTree(DECISION)
                .selectItemInFolder(DECISION, "Hello");

        assertThat(editorPage.getCenterTable().getCellText(6, 4))
                .as("Cell (6,4) should retain first edit value after restoring to row 2")
                .isEqualTo("Good Morning1");
        assertThat(editorPage.getCenterTable().getCellText(7, 4))
                .as("Cell (7,4) should retain second edit value after restoring to row 2")
                .isEqualTo("Good Afternoon1");
        assertThat(editorPage.getCenterTable().getCellText(8, 4))
                .as("Cell (8,4) should be reverted to original after restoring to row 2")
                .isEqualTo("Good Evening");

        editorPage.getEditorToolbarPanelComponent().clickSave();
        editorPage.getSaveChangesComponent().clickSave();
        editorPage.waitUntilSpinnerLoaded();

        editorPage.getEditorToolbarPanelComponent().navigateToProjectRoot(projectName);
        editorPage.getEditorLeftProjectModuleSelectorComponent().selectModule(projectName, "Main");
        editorPage.getEditorLeftRulesTreeComponent()
                .setViewFilter(EditorLeftRulesTreeComponent.FilterOptions.BY_TYPE)
                .expandFolderInTree(DECISION)
                .selectItemInFolder(DECISION, "Hello");

        changesDialog = editorPage.getEditorToolbarPanelComponent()
                .clickMore()
                .clickChanges();
        assertThat(changesDialog.getNoChangesMessage())
                .as("Local history should be cleared after project save")
                .isEqualTo("No changes in history");

        editorPage.getEditorToolbarPanelComponent().clickMore().clickRevisions();
        EditorRevisionsTabComponent revisionsTab = new EditorRevisionsTabComponent();
        revisionsTab.waitForTableToLoad();
        assertThat(revisionsTab.getRowCount())
                .as("Should have 2 revisions after save (creation + save)")
                .isEqualTo(2);

        RepositoryPage repositoryPage = editorPage.getTabSwitcherComponent().selectTab(TabSwitcherComponent.TabName.REPOSITORY);
        assertThat(repositoryPage.openProjectDetail(projectName).openFilesTab().isFolderPresent(".history"))
                .as(".history folder should not be visible in the repository tree after save")
                .isFalse();

        editorPage = new EditorPage();
        editorPage.getEditorLeftProjectModuleSelectorComponent().selectModule(projectName, "Main");
        editorPage.getEditorLeftRulesTreeComponent()
                .setViewFilter(EditorLeftRulesTreeComponent.FilterOptions.BY_TYPE)
                .expandFolderInTree(DECISION)
                .selectItemInFolder(DECISION, "Hello");

        editorPage.getEditorToolbarPanelComponent().getEditTableBtn().click();
        editorPage.getCenterTable().editCell(6, 4, "Good Morning2");
        editorPage.getEditorTableActionsPanelComponent().clickSaveChanges();

        changesDialog = editorPage.getEditorToolbarPanelComponent()
                .clickMore()
                .clickChanges();
        assertThat(changesDialog.getChangesTitle())
                .as("Should show 1 local change after editing a saved project")
                .isEqualTo("Local Changes");
        assertThat(changesDialog.getChangesCount())
                .as("Should show 1 local change after editing a saved project")
                .isEqualTo(1);
        assertThat(changesDialog.getRowCount())
                .as("Should be 2 rows in history")
                .isEqualTo(2);

        changesDialog.setCompareCheckbox(1, true);
        changesDialog.setCompareCheckbox(2, true);
        CompareLocalChangesDialogComponent compareDialog = changesDialog.clickCompare();
        compareDialog.waitForDialogToAppear();
        compareDialog.openTreeNode("Rules");
        compareDialog.clickTreeNode("Rules String Hello (Integer hour)");

        assertThat(compareDialog.isDifferenceShown(1, "Good Morning1"))
                .as("The saved state should show 'Good Morning1' as what differs after the edit")
                .isTrue();
        assertThat(compareDialog.isDifferenceShown(2, "Good Morning2"))
                .as("The working copy should show 'Good Morning2' as what differs after the edit")
                .isTrue();
        compareDialog.close();
    }
}
