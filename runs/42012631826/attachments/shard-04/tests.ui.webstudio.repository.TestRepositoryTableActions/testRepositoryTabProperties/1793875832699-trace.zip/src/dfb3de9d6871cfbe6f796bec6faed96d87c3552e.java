package tests.ui.webstudio.repository;

import configuration.annotations.Description;
import configuration.annotations.TestCaseId;
import configuration.annotations.AppContainerConfig;
import configuration.appcontainer.AppContainerStartParameters;
import configuration.driver.DriverPool;
import domain.api.UsersMethod;
import domain.serviceclasses.constants.User;
import domain.serviceclasses.models.UserData;
import domain.ui.webstudio.components.common.CreateNewProjectComponent;
import domain.ui.webstudio.components.common.TabSwitcherComponent;
import domain.ui.webstudio.components.repositorytabcomponents.DeployModalComponent;
import domain.ui.webstudio.pages.mainpages.EditorPage;
import domain.ui.webstudio.pages.mainpages.ProjectDetailPage;
import domain.ui.webstudio.pages.mainpages.RepositoryPage;
import helpers.service.DeployInfrastructureService;
import helpers.service.LoginService;
import helpers.service.UserService;
import helpers.utils.StringUtil;
import helpers.utils.TestDataUtil;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import tests.BaseTest;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

public class TestRepositoryTableActions extends BaseTest {

    private static final Map<String, String> additionalContainerFiles = new HashMap<>();

    @Override
    protected Map<String, String> additionalContainerFiles() {
        return additionalContainerFiles;
    }
    private DeployInfrastructureService deployInfra;

    @Override
    @BeforeMethod
    public void beforeMethod(ITestResult result) {
        additionalContainerFiles.clear();
        deployInfra = DeployInfrastructureService.builder()
                .withPostgres()
                .build();
        deployInfra.start();
        additionalContainerFiles.putAll(deployInfra.getFilesToCopy());
        super.beforeMethod(result);
    }

    @Override
    @AfterMethod
    public void afterMethod(ITestResult result) {
        super.afterMethod(result);
        deployInfra.cleanup();
    }

    private static final String TEMPLATE_NAME = "Sample Project";

    private static final String STATUS_OPENED = "No Changes";
    private static final String STATUS_CLOSED = "Closed";

    private static final String ACTION_OPEN  = "Open";
    private static final String ACTION_CLOSE = "Close";

    private static final String MAIN_XLS  = "TestRepositoryTableActions.Main.xls";
    private static final String RULES_XLS = "TestRepositoryTableActions.rules.xls";

    private static final String SECOND_USER          = "repo_table_second_user";
    private static final String SECOND_USER_PASSWORD = "Test123!";
    private static final String SECOND_USER_FIRST    = "Second";
    private static final String SECOND_USER_LAST     = "User";

    private static final String VIEWER_USER          = "repo_table_viewer_user";
    private static final String VIEWER_USER_PASSWORD = "Test123!";

    @Test
    @TestCaseId("EPBDS-12712")
    @Description("Repository table action buttons: open/close/deploy row actions; viewer user access")
    @AppContainerConfig(startParams = AppContainerStartParameters.DEPLOY_STUDIO_PARAMS)
    public void testTableActionButtons() {
        String projectName1 = "TestTableActionButtons_P1_" + System.currentTimeMillis();
        String projectName2 = "TestTableActionButtons_P2_" + System.currentTimeMillis();
        String projectName3 = "TestTableActionButtons_P3_" + System.currentTimeMillis();

        LoginService loginService = new LoginService(DriverPool.getPage());
        EditorPage editorPage = loginService.login(UserService.getUser(User.ADMIN));

        editorPage.openUserMenu()
                .navigateToAdministration()
                .navigateToUsersPage()
                .clickAddUser()
                .setUsername(VIEWER_USER)
                .setEmail(VIEWER_USER + "@test.com")
                .setPassword(VIEWER_USER_PASSWORD)
                .setFirstName("Viewer")
                .setLastName("User")
                .clickAddRoleBtn()
                .setRoleRepository(0, "Design")
                .setRole(0, "Viewer")
                .saveUser();
        UserData viewerUser = new UserData(VIEWER_USER, VIEWER_USER_PASSWORD);

        editorPage = new EditorPage();
        RepositoryPage repositoryPage = editorPage.getTabSwitcherComponent()
                .selectTab(TabSwitcherComponent.TabName.REPOSITORY);
        repositoryPage.createProject(CreateNewProjectComponent.TabName.TEMPLATE, projectName1, TEMPLATE_NAME);

        DeployModalComponent deployModal = repositoryPage.clickDeploy(projectName1);
        String deploymentName = StringUtil.generateUniqueName("Deploy");
        deployModal.deployWithAllFields(null, deploymentName, "First deploy");
        assertThat(deployModal.isSuccessNotificationVisible())
                .as("Deploy should succeed with success notification")
                .isTrue();
        repositoryPage.closeAllMessages();

        assertThat(repositoryPage.isDeployAvailable(projectName1))
                .as("'Deploy' row action should be present when a deploy repo is configured")
                .isTrue();

        assertThat(repositoryPage.isProjectActionAvailable(projectName1, ACTION_CLOSE))
                .as("'Close' row action should be present for open project")
                .isTrue();
        repositoryPage.closeProject(projectName1);
        assertThat(repositoryPage.getProjectStatusFromDetail(projectName1))
                .as("Project status should be 'Closed' after Close row action")
                .isEqualTo(STATUS_CLOSED);

        assertThat(repositoryPage.isProjectActionAvailable(projectName1, ACTION_OPEN))
                .as("'Open' row action should be present for closed project")
                .isTrue();
        repositoryPage.openProject(projectName1);
        assertThat(repositoryPage.getProjectStatusFromDetail(projectName1))
                .as("Project status should be 'No Changes' after Open row action")
                .isEqualTo(STATUS_OPENED);

        deployModal = repositoryPage.clickDeploy(projectName1);
        assertThat(deployModal.isModalVisible())
                .as("Clicking Deploy row action should open DeployModal for redeploy")
                .isTrue();
        deployModal.clickCancel();

        repositoryPage.createProject(CreateNewProjectComponent.TabName.EXCEL_FILES, projectName2, MAIN_XLS);
        assertThat(repositoryPage.getProjectStatusFromDetail(projectName2))
                .as("Newly created Excel project status should be 'No Changes'")
                .isEqualTo(STATUS_OPENED);

        repositoryPage.closeProject(projectName2);
        assertThat(repositoryPage.getProjectStatusFromDetail(projectName2))
                .as("Project2 status should be 'Closed' after Close")
                .isEqualTo(STATUS_CLOSED);

        repositoryPage.openProject(projectName2);
        assertThat(repositoryPage.getProjectStatusFromDetail(projectName2))
                .as("Project2 status should be 'No Changes' after Open")
                .isEqualTo(STATUS_OPENED);

        repositoryPage.createProject(CreateNewProjectComponent.TabName.TEMPLATE, projectName3, TEMPLATE_NAME);

        editorPage = new EditorPage();
        editorPage.openUserMenu().signOut();
        editorPage = loginService.login(viewerUser);
        repositoryPage = editorPage.getTabSwitcherComponent()
                .selectTab(TabSwitcherComponent.TabName.REPOSITORY);

        assertThat(repositoryPage.isProjectActionAvailable(projectName3, ACTION_OPEN))
                .as("'Open' row action should be present for viewer on closed project")
                .isTrue();
        repositoryPage.openProject(projectName3);
        assertThat(repositoryPage.getProjectStatusFromDetail(projectName3))
                .as("Project3 status should be 'No Changes' after viewer Open")
                .isEqualTo(STATUS_OPENED);

        assertThat(repositoryPage.isProjectActionAvailable(projectName3, ACTION_CLOSE))
                .as("'Close' row action should be present for viewer on open project")
                .isTrue();
        repositoryPage.closeProject(projectName3);
        assertThat(repositoryPage.getProjectStatusFromDetail(projectName3))
                .as("Project3 status should be 'Closed' after viewer Close")
                .isEqualTo(STATUS_CLOSED);
    }

    @Test
    @TestCaseId("IPBQA-29847")
    @Description("Repository project properties: the Modified author equals each committing user's profile display "
            + "name, the date stays valid and the Revision is present across multi-user modifications")
    @AppContainerConfig(startParams = AppContainerStartParameters.DEPLOY_STUDIO_PARAMS)
    public void testRepositoryTabProperties() {
        String projectName = "TestRepositoryTabProperties_" + System.currentTimeMillis();

        LoginService loginService = new LoginService(DriverPool.getPage());
        EditorPage editorPage = loginService.login(UserService.getUser(User.ADMIN));

        editorPage.openUserMenu()
                .navigateToAdministration()
                .navigateToUsersPage()
                .clickAddUser()
                .setUsername(SECOND_USER)
                .setEmail(SECOND_USER + "@test.com")
                .setPassword(SECOND_USER_PASSWORD)
                .setFirstName(SECOND_USER_FIRST)
                .setLastName(SECOND_USER_LAST)
                .clickAddRoleBtn()
                .setRoleRepository(0, "Design")
                .setRole(0, "Contributor")
                .saveUser();
        UserData secondUser = new UserData(SECOND_USER, SECOND_USER_PASSWORD);

        editorPage = new EditorPage();
        RepositoryPage repositoryPage = editorPage.getTabSwitcherComponent()
                .selectTab(TabSwitcherComponent.TabName.REPOSITORY);
        repositoryPage.createProject(CreateNewProjectComponent.TabName.TEMPLATE, projectName, TEMPLATE_NAME);

        ProjectDetailPage detail = repositoryPage.openProjectsList().openProjectDetail(projectName);
        String creationLastChange = detail.getOverviewLastChange();
        String adminDisplayName = new UsersMethod().getProfileDisplayName(UserService.getUser(User.ADMIN));
        assertThat(detail.getModifiedBy())
                .as("Overview 'Modified' author after creation should equal the admin's profile display name")
                .isEqualTo(adminDisplayName);
        assertThat(containsValidDate(creationLastChange))
                .as("Overview 'Last change' should contain a valid current date, but was: " + creationLastChange)
                .isTrue();
        assertThat(detail.getOverviewRevision())
                .as("Overview Revision (commit hash) should be present")
                .isNotEmpty();
        repositoryPage.openProjectsList();

        editorPage = new EditorPage();
        editorPage.openUserMenu().signOut();
        editorPage = loginService.login(secondUser);
        repositoryPage = editorPage.getTabSwitcherComponent()
                .selectTab(TabSwitcherComponent.TabName.REPOSITORY);

        repositoryPage.openProject(projectName);
        repositoryPage.openProjectDetail(projectName)
                .openFilesTab()
                .uploadFile(TestDataUtil.getFilePathFromResources(RULES_XLS));
        repositoryPage.openProjectsList().saveProjectWithCommitInfo(projectName, "Second user upload");

        editorPage = new EditorPage();
        repositoryPage = editorPage.getTabSwitcherComponent()
                .selectTab(TabSwitcherComponent.TabName.REPOSITORY);
        detail = repositoryPage.openProjectsList().openProjectDetail(projectName);
        String modifiedLastChange = detail.getOverviewLastChange();
        String secondUserDisplayName = new UsersMethod().getProfileDisplayName(secondUser);
        assertThat(detail.getModifiedBy())
                .as("Overview 'Modified' author after modification should equal the second user's profile display name")
                .isEqualTo(secondUserDisplayName);
        assertThat(containsValidDate(modifiedLastChange))
                .as("Overview 'Last change' should contain a valid current date after modification")
                .isTrue();
        assertThat(modifiedLastChange)
                .as("Overview 'Last change' should change after the second user's modification (multi-user)")
                .isNotEqualTo(creationLastChange);
        assertThat(detail.getOverviewRevision())
                .as("Overview Revision should be present after modification")
                .isNotEmpty();
        repositoryPage.openProjectsList();

        editorPage = new EditorPage();
        editorPage.openUserMenu().signOut();
        editorPage = loginService.login(UserService.getUser(User.ADMIN));
        repositoryPage = editorPage.getTabSwitcherComponent()
                .selectTab(TabSwitcherComponent.TabName.REPOSITORY);

        DeployModalComponent deployModal = repositoryPage.clickDeploy(projectName);
        deployModal.deployWithAllFields(null, StringUtil.generateUniqueName("Deploy"), "Deploy for properties verification");
        assertThat(deployModal.isSuccessNotificationVisible())
                .as("Deploy should succeed with success notification")
                .isTrue();
        repositoryPage.closeAllMessages();

        detail = repositoryPage.openProjectsList().openProjectDetail(projectName);
        assertThat(containsValidDate(detail.getOverviewLastChange()))
                .as("Overview 'Last change' should still contain a valid date after deploy")
                .isTrue();
        assertThat(detail.getOverviewRevision())
                .as("Overview Revision should still be present after deploy")
                .isNotEmpty();
    }

    private boolean containsValidDate(String value) {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        LocalDate now = LocalDate.now(ZoneId.of("America/New_York"));
        String today     = now.format(fmt);
        String yesterday = now.minusDays(1).format(fmt);
        String tomorrow  = now.plusDays(1).format(fmt);
        return value.contains(today) || value.contains(yesterday) || value.contains(tomorrow);
    }
}
