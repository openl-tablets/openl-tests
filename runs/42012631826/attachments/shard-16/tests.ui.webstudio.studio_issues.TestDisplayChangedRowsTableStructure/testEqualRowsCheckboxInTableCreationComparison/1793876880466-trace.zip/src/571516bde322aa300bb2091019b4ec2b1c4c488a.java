package domain.ui.webstudio.components.editortabcomponents;

import configuration.core.ui.WebElement;
import configuration.driver.DriverPool;
import domain.ui.webstudio.components.BaseComponent;
import helpers.utils.WaitUtil;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

@Getter
public class CopyTableDialogComponent extends BaseComponent {

    private static final String MODAL =
            "//div[contains(@class,'ant-modal')][.//div[contains(@class,'ant-modal-title')][contains(normalize-space(.),'Copy table')]]";
    private static final String OPEN_DROPDOWN =
            "//div[contains(@class,'ant-select-dropdown') and not(contains(@class,'ant-select-dropdown-hidden'))]";
    private static final int MAX_PROPERTY_ROWS = 10;
    private static final int VERSION_PARTS = 3;

    private WebElement modal;
    private WebElement dialogTitle;
    private WebElement nameTextBox;
    private WebElement moduleComboBox;
    private WebElement sheetComboBox;
    private WebElement copyButton;
    private WebElement propertyNameTemplate;
    private WebElement propertyValueTemplate;
    private WebElement versionPartTemplate;
    private WebElement insertPropertyTemplate;

    public CopyTableDialogComponent() {
        super(DriverPool.getPage());
        initializeElements();
    }

    public CopyTableDialogComponent(WebElement rootLocator) {
        super(rootLocator);
        initializeElements();
    }

    private void initializeElements() {
        modal = new WebElement(page, "xpath=" + MODAL, "copyTableModal");
        dialogTitle = new WebElement(page, "xpath=" + MODAL + "//div[contains(@class,'ant-modal-title')]", "copyTableTitle");
        nameTextBox = new WebElement(page,
                "xpath=//*[@data-testid='copy-table-name']//input | //input[@data-testid='copy-table-name']", "copyTableName");
        moduleComboBox = new WebElement(page, "xpath=//*[@data-testid='copy-table-module']", "copyTableModule");
        sheetComboBox = new WebElement(page, "xpath=//*[@data-testid='copy-table-sheet']", "copyTableSheet");
        copyButton = new WebElement(page,
                "xpath=" + MODAL + "//div[contains(@class,'ant-modal-footer')]//button[.//span[normalize-space()='Copy']]",
                "copyTableSubmit");
        propertyNameTemplate = new WebElement(page,
                "xpath=//*[@data-testid='copy-table-property-name-%1$s']//input | //input[@data-testid='copy-table-property-name-%1$s']",
                "copyTablePropertyName");
        propertyValueTemplate = new WebElement(page,
                "xpath=//*[@data-testid='copy-table-property-value-%1$s']//input | //input[@data-testid='copy-table-property-value-%1$s']",
                "copyTablePropertyValue");
        versionPartTemplate = new WebElement(page,
                "xpath=//input[@data-testid='copy-table-property-value-%1$s-%2$s']",
                "copyTableVersionPart");
        insertPropertyTemplate = new WebElement(page,
                "xpath=//*[@data-testid='copy-table-property-row-%s']//button[@aria-label='Insert property above']",
                "copyTableInsertProperty");
    }

    public CopyTableDialogComponent waitForDialogToAppear() {
        copyButton.waitForVisible(DEFAULT_TIMEOUT_MS);
        return this;
    }

    public CopyTableDialogComponent selectCopyAs(String value) {
        return waitForDialogToAppear();
    }

    public CopyTableDialogComponent setName(String name) {
        nameTextBox.waitForVisible(DEFAULT_TIMEOUT_MS);
        boolean accepted = WaitUtil.waitForCondition(() -> {
            retype(nameTextBox, name);
            return name.equals(nameTextBox.getCurrentInputValue());
        }, DEFAULT_TIMEOUT_MS, 300, "Waiting for the copy dialog to hold only the requested table name");
        if (!accepted) {
            throw new IllegalStateException("The copy dialog kept the name '" + nameTextBox.getCurrentInputValue()
                    + "' instead of '" + name + "'");
        }
        return this;
    }

    public CopyTableDialogComponent setVersion(String version) {
        return setProperty("version", version);
    }

    public CopyTableDialogComponent setSaveTo(String sheetName) {
        if (sheetName != null && !sheetName.isEmpty()) {
            selectFromDropdown(sheetComboBox, sheetName);
        }
        return this;
    }

    public CopyTableDialogComponent setModule(String moduleName) {
        selectFromDropdown(moduleComboBox, moduleName);
        return this;
    }

    public CopyTableDialogComponent setTextProperty(String propertyLabel, String value) {
        return setProperty(propertyLabel, value);
    }

    public CopyTableDialogComponent setSelectProperty(String propertyLabel, String value) {
        return setProperty(propertyLabel, value);
    }

    public CopyTableDialogComponent setProperty(String propertyLabel, String value) {
        waitForDialogToAppear();
        String row = String.valueOf(firstFreePropertyRow());
        selectPropertyName(row, propertyLabel);
        if (isVersionBacked(row)) {
            setVersionParts(row, value);
            return this;
        }
        WebElement propertyValue = propertyValueTemplate.format(row);
        propertyValue.waitForVisible(DEFAULT_TIMEOUT_MS);
        if (isListBacked(row)) {
            pickPropertyValue(row, propertyValue, value);
        } else {
            WaitUtil.waitForCondition(() -> {
                retype(propertyValue, value);
                return value.equals(propertyValue.getCurrentInputValue());
            }, DEFAULT_TIMEOUT_MS, 300, "Waiting for the property value to hold the requested value");
        }
        return this;
    }

    private void selectPropertyName(String row, String propertyLabel) {
        WebElement name = propertyNameTemplate.format(row);
        name.waitForVisible(DEFAULT_TIMEOUT_MS);
        name.click();
        name.fillSequentially(propertyLabel);
        WebElement option = new WebElement(page, "xpath=" + OPEN_DROPDOWN
                + "//div[contains(@class,'ant-select-item-option')][" + lowerCaseOf("@title") + "='"
                + propertyLabel.toLowerCase() + "']", "copyTablePropertyNameOption");
        if (!WaitUtil.waitForCondition(option::exists, DEFAULT_TIMEOUT_MS, 200,
                "Waiting for the property list to offer '" + propertyLabel + "'")) {
            throw new IllegalStateException("The copy dialog offers no property named '" + propertyLabel
                    + "'. The list is searched by the property's displayed name, so pass that name, for example"
                    + " 'Countries' for the country dimension");
        }
        option.click(DEFAULT_TIMEOUT_MS / 2);
        WebElement chosen = new WebElement(page,
                "xpath=//*[@data-testid='copy-table-property-name-" + row + "']//*[contains(@class,'ant-select-content')]", "copyTableChosenProperty");
        if (!WaitUtil.waitForCondition(
                () -> propertyLabel.equalsIgnoreCase(chosen.getText().trim()), DEFAULT_TIMEOUT_MS, 200,
                "Waiting for the property row to hold '" + propertyLabel + "'")) {
            throw new IllegalStateException("The copy dialog kept the property '" + chosen.getText().trim()
                    + "' instead of '" + propertyLabel + "'");
        }
    }

    private String lowerCaseOf(String expression) {
        return "translate(" + expression + ",'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')";
    }

    private boolean isVersionBacked(String row) {
        WebElement firstPart = versionPartTemplate.format(row, "0");
        WaitUtil.waitForCondition(() -> firstPart.exists() || propertyValueTemplate.format(row).exists(),
                DEFAULT_TIMEOUT_MS, 200, "Waiting for the property value editor to render");
        return firstPart.exists();
    }

    private void setVersionParts(String row, String version) {
        int[] numbers = versionNumbers(version);
        for (int part = 0; part < VERSION_PARTS; part++) {
            String expected = String.valueOf(numbers[part]);
            WebElement field = versionPartTemplate.format(row, String.valueOf(part));
            field.waitForVisible(DEFAULT_TIMEOUT_MS);
            boolean accepted = WaitUtil.waitForCondition(() -> {
                if (expected.equals(field.getCurrentInputValue())) {
                    return true;
                }
                field.fill(expected);
                return expected.equals(field.getCurrentInputValue());
            }, DEFAULT_TIMEOUT_MS, 300, "Waiting for the version part to hold the requested number");
            if (!accepted) {
                throw new IllegalStateException("The version editor kept '" + field.getCurrentInputValue()
                        + "' instead of '" + expected + "' in part " + part);
            }
        }
    }

    private int[] versionNumbers(String version) {
        String[] parts = version == null ? new String[0] : version.trim().split("\\.");
        if (parts.length > VERSION_PARTS) {
            throw new IllegalArgumentException("The version editor takes three numbers, so '" + version
                    + "' cannot be entered");
        }
        int[] numbers = new int[VERSION_PARTS];
        for (int part = 0; part < VERSION_PARTS; part++) {
            numbers[part] = part < parts.length ? nonNegativeNumberOf(parts[part], version) : 0;
        }
        return numbers;
    }

    private int nonNegativeNumberOf(String text, String version) {
        try {
            int number = Integer.parseInt(text.trim());
            if (number < 0) {
                throw new NumberFormatException(text);
            }
            return number;
        } catch (NumberFormatException notANumber) {
            throw new IllegalArgumentException("The version editor takes three non-negative numbers, so '"
                    + version + "' cannot be entered", notANumber);
        }
    }

    private boolean isListBacked(String row) {
        return new WebElement(page, "xpath=//*[@data-testid='copy-table-property-value-" + row + "'][contains(@class,'ant-select')]",
                "copyTablePropertySelect").exists();
    }

    private void pickPropertyValue(String row, WebElement field, String value) {
        WebElement option = new WebElement(page,
                "xpath=//div[contains(@class,'ant-select-dropdown')][not(contains(@class,'ant-select-dropdown-hidden'))]"
                        + "//div[contains(@class,'ant-select-item-option')][@title='" + value + "']", "copyTablePropertyOption");
        field.click();
        field.fillSequentially(value);
        if (!WaitUtil.waitForCondition(option::exists, DEFAULT_TIMEOUT_MS / 2, 200,
                "Waiting for the property to offer '" + value + "'")) {
            field.click();
            if (!WaitUtil.waitForCondition(option::exists, DEFAULT_TIMEOUT_MS / 2, 200,
                    "Waiting for the property to offer '" + value + "'")) {
                throw new IllegalStateException("The copy dialog offers no '" + value + "' for this property");
            }
        }
        option.click(DEFAULT_TIMEOUT_MS / 2);
        WebElement selected = new WebElement(page,
                "xpath=//*[@data-testid='copy-table-property-value-" + row + "']"
                        + "//*[contains(@class,'ant-select-selection-item')][@title='" + value + "']", "copyTablePropertySelection");
        if (!WaitUtil.waitForCondition(selected::exists, DEFAULT_TIMEOUT_MS / 2, 200,
                "Waiting for the property to hold '" + value + "'")) {
            throw new IllegalStateException("The copy dialog did not take '" + value + "' for this property");
        }
    }

    private void retype(WebElement field, String text) {
        field.clearByKeyCombination();
        field.fillSequentially(text);
    }

    private int firstFreePropertyRow() {
        for (int row = 0; row < MAX_PROPERTY_ROWS; row++) {
            WebElement name = propertyNameTemplate.format(String.valueOf(row));
            if (!name.exists()) {
                if (row > 0) {
                    insertPropertyTemplate.format(String.valueOf(row - 1)).click();
                }
                return row;
            }
            if (name.getCurrentInputValue().isBlank()) {
                return row;
            }
        }
        throw new IllegalStateException("The copy dialog offers no free property row");
    }

    private void selectFromDropdown(WebElement select, String value) {
        select.waitForVisible(DEFAULT_TIMEOUT_MS).click();
        new WebElement(page, "xpath=//div[contains(@class,'ant-select-item-option')][@title='" + value + "']",
                "dropdownOption").waitForVisible(DEFAULT_TIMEOUT_MS).click();
    }

    public boolean isCopyButtonEnabled() {
        return copyButton.isEnabled();
    }

    public void clickCopy() {
        copyButton.waitForVisible(DEFAULT_TIMEOUT_MS).click();
        copyButton.waitForHidden(DEFAULT_TIMEOUT_MS);
        waitUntilSpinnerLoaded();
    }

    public String getName() {
        return nameTextBox.getCurrentInputValue();
    }

    public String getVersion() {
        if (isVersionBacked("0")) {
            List<String> numbers = new ArrayList<>();
            for (int part = 0; part < VERSION_PARTS; part++) {
                numbers.add(versionPartTemplate.format("0", String.valueOf(part)).getCurrentInputValue());
            }
            return String.join(".", numbers);
        }
        WebElement firstValue = propertyValueTemplate.format("0");
        return firstValue.exists() ? firstValue.getCurrentInputValue() : "";
    }

    public boolean isDialogVisible() {
        return modal.isVisible(DEFAULT_TIMEOUT_MS / 2);
    }

    public CopyTableDialogComponent waitForDialogToClose() {
        WaitUtil.waitForCondition(() -> !modal.isVisible(500), DEFAULT_TIMEOUT_MS, 250,
                "Waiting for the copy table dialog to close");
        return this;
    }
}
