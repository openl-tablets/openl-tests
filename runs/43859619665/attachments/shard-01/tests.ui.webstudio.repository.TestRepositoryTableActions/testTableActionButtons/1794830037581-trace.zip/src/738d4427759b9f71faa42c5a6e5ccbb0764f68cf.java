package domain.ui.webstudio.components.common;

import domain.ui.webstudio.components.BaseComponent;
import configuration.core.ui.WebElement;
import configuration.driver.DriverPool;

import java.util.List;

public class MessageComponent extends BaseComponent {

    private static final int CLOSE_TIMEOUT_MS = 500;
    private static final String IS_NOTICE = "contains(concat(' ',normalize-space(@class),' '),' ant-notification-notice ')";

    public record NoticeColors(String background, String text) {
    }

    private List<WebElement> message;
    private WebElement notice;
    private WebElement closeBtn;

    public MessageComponent() {
        super(DriverPool.getPage());
        initializeComponents();
    }

    public MessageComponent(WebElement rootLocator) {
        super(rootLocator);
        initializeComponents();
    }

    private void initializeComponents() {
        message = createScopedElementList("xpath=.//div[contains(@class,'ant-notification-notice-title')]"
                + " | .//div[contains(@class,'ant-notification-notice-message')]", "Message Content List");
        notice = createScopedElement("xpath=./ancestor-or-self::div[" + IS_NOTICE + "][1] | .//div[" + IS_NOTICE + "]", "Message Notice");
        closeBtn = createScopedElement("xpath=./parent::div[" + IS_NOTICE + "]/button[contains(@class,'ant-notification-notice-close')]"
                + " | .//a[@aria-label='Close'] | .//button[@class='ant-notification-notice-close']", "Close Message Button");
    }

    public String getMessageText() {
        if(!message.isEmpty()) {
            String text = message.getFirst().getText();
            LOGGER.info("Trying to extract text from the element: {}", text);
            return text;
        }
        return "";
    }

    public NoticeColors getColors() {
        return new NoticeColors(notice.getCssValue("background-color"), notice.getCssValue("color"));
    }

    public String getFullText() {
        return getRootLocator().getText().replaceAll("\\s+", " ").trim();
    }

    public void closeMessage() {
        try {
            closeBtn.click(CLOSE_TIMEOUT_MS);
        } catch (Exception ignored) {}
    }
}
