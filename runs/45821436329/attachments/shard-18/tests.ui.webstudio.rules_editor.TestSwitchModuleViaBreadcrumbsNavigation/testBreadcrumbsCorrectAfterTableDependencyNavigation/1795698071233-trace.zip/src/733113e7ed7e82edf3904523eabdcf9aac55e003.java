package tests.ui.webstudio.rules_editor;

import configuration.annotations.Description;
import configuration.annotations.TestCaseId;
import configuration.annotations.AppContainerConfig;
import configuration.appcontainer.AppContainerPool;
import configuration.appcontainer.AppContainerStartParameters;
import configuration.driver.DriverPool;
import configuration.projectconfig.ProjectConfiguration;
import configuration.projectconfig.PropertyNameSpace;
import domain.serviceclasses.constants.User;
import domain.ui.webstudio.components.common.CreateNewProjectComponent;
import domain.ui.webstudio.components.common.TabSwitcherComponent;
import domain.ui.webstudio.pages.mainpages.EditorPage;
import domain.ui.webstudio.pages.mainpages.RepositoryPage;
import helpers.service.LoginService;
import helpers.service.UserService;
import domain.ui.webstudio.components.editortabcomponents.leftmenu.EditorLeftRulesTreeComponent;
import helpers.utils.LogsUtil;
import org.testng.annotations.Test;
import tests.BaseTest;

import domain.ui.webstudio.components.common.CreateNewProjectComponent;

import static org.assertj.core.api.Assertions.assertThat;
import static domain.ui.webstudio.components.editortabcomponents.leftmenu.TableTypeFolders.DECISION;

public class TestSwitchModuleViaBreadcrumbsNavigation extends BaseTest {

    private static final int TREE_EXPAND_DEADLINE_MS = Integer.parseInt(
            ProjectConfiguration.getProperty(PropertyNameSpace.PLAYWRIGHT_DEFAULT_TIMEOUT));

    private static final String NAME_PROJECT_FIRST = "TestSwitchModuleViaBreadcrumbsNavigationFirst";
    private static final String ZIP_FILE_FIRST = "RulesEditor.TestSwitchModuleViaBreadcrumbsNavigationFirst.zip";
    private static final String NAME_PROJECT_SECOND = "TestSwitchModuleViaBreadcrumbsNavigationSecond";
    private static final String ZIP_FILE_SECOND = "RulesEditor.TestSwitchModuleViaBreadcrumbsNavigationSecond.zip";

    @Test
    @TestCaseId("IPBQA-31804")
    @Description("Switch Module Via Breadcrumbs Navigation - breadcrumb switching through multiple modules, performance check")
    @AppContainerConfig(startParams = AppContainerStartParameters.DEFAULT_STUDIO_PARAMS)
    public void testSwitchModuleViaBreadcrumbsNavigation() {
        LoginService loginService = new LoginService(DriverPool.getPage());
        EditorPage editorPage = loginService.login(UserService.getUser(User.ADMIN));

        RepositoryPage repositoryPage = editorPage.getTabSwitcherComponent()
                .selectTab(TabSwitcherComponent.TabName.REPOSITORY);
        repositoryPage.createProject(CreateNewProjectComponent.TabName.ZIP_ARCHIVE, NAME_PROJECT_FIRST, ZIP_FILE_FIRST);
        repositoryPage.createProject(CreateNewProjectComponent.TabName.ZIP_ARCHIVE, NAME_PROJECT_SECOND, ZIP_FILE_SECOND);

        editorPage = new EditorPage();
        editorPage.getEditorLeftProjectModuleSelectorComponent().selectModule(NAME_PROJECT_FIRST, "module_AR");
        editorPage.getEditorToolbarPanelComponent().selectProjectBreadcrumbs(NAME_PROJECT_SECOND);
        editorPage.getEditorLeftProjectModuleSelectorComponent().selectModule(NAME_PROJECT_SECOND, "module_AZ");
        assertThat(editorPage.getProblemsPanelComponent().hasErrors())
                .as("No errors should be present after switching to module_AZ")
                .isFalse();

        editorPage.getEditorToolbarPanelComponent().selectProjectBreadcrumbs(NAME_PROJECT_FIRST);
        editorPage.getEditorLeftProjectModuleSelectorComponent().selectModule(NAME_PROJECT_FIRST, "module_AR");
        editorPage.getEditorToolbarPanelComponent().selectBreadcrumbModule(NAME_PROJECT_FIRST, "module_AZ");
        editorPage.getEditorToolbarPanelComponent().selectBreadcrumbModule(NAME_PROJECT_FIRST, "module_MN");
        editorPage.getEditorToolbarPanelComponent().selectBreadcrumbModule(NAME_PROJECT_FIRST, "module_MT");
        editorPage.getEditorToolbarPanelComponent().selectBreadcrumbModule(NAME_PROJECT_FIRST, "module_LA");
        editorPage.getEditorToolbarPanelComponent().selectBreadcrumbModule(NAME_PROJECT_FIRST, "module_OH");
        editorPage.getEditorToolbarPanelComponent().selectBreadcrumbModule(NAME_PROJECT_FIRST, "module_OK");
        editorPage.getEditorToolbarPanelComponent().selectBreadcrumbModule(NAME_PROJECT_FIRST, "module_OR");
        editorPage.getEditorToolbarPanelComponent().selectBreadcrumbModule(NAME_PROJECT_FIRST, "module_TN");
        editorPage.getEditorToolbarPanelComponent().selectBreadcrumbModule(NAME_PROJECT_FIRST, "module_KS");
        editorPage.getEditorToolbarPanelComponent().selectBreadcrumbModule(NAME_PROJECT_FIRST, "module_KY");
        editorPage.getEditorToolbarPanelComponent().selectBreadcrumbModule(NAME_PROJECT_FIRST, "module_RI");
        editorPage.getEditorToolbarPanelComponent().selectBreadcrumbModule(NAME_PROJECT_FIRST, "module_SC");

        long startTime = System.currentTimeMillis();
        editorPage.getEditorLeftRulesTreeComponent()
                .setViewFilter(EditorLeftRulesTreeComponent.FilterOptions.BY_TYPE)
                .expandFolderInTree(DECISION)
                .selectItemInFolder(DECISION, "SmartRule1");
        long elapsedTime = System.currentTimeMillis() - startTime;
        assertThat(elapsedTime)
                .as("Expanding and selecting tree item should fit into the framework's default wait")
                .isLessThanOrEqualTo(TREE_EXPAND_DEADLINE_MS);

        LogsUtil.inspectLogFile(AppContainerPool.get());
    }

    @Test
    @TestCaseId("EPBDS-12366")
    @Description("EPBDS-12366: Breadcrumbs must show correct module after navigating from Table Dependencies view")
    @AppContainerConfig(startParams = AppContainerStartParameters.DEFAULT_STUDIO_PARAMS)
    public void testBreadcrumbsCorrectAfterTableDependencyNavigation() {
        LoginService loginService = new LoginService(DriverPool.getPage());
        EditorPage editorPage = loginService.login(UserService.getUser(User.ADMIN));

        RepositoryPage repositoryPage = editorPage.getTabSwitcherComponent()
                .selectTab(TabSwitcherComponent.TabName.REPOSITORY);
        String projectName = "Example3_" + System.currentTimeMillis();
        repositoryPage.createProject(CreateNewProjectComponent.TabName.TEMPLATE, projectName, "Example 3 - Auto Policy Calculation");

        editorPage = new EditorPage();
        editorPage.getEditorLeftProjectModuleSelectorComponent()
                .selectModule(projectName, "AutoPolicyTests");

        editorPage.getEditorToolbarPanelComponent().clickMore().clickTableDependencies();

        editorPage.clickTableInDependenciesView("DetermineDriverPremium");

        String breadcrumbModule = editorPage.getEditorToolbarPanelComponent().getBreadcrumbsModuleName().trim();
        assertThat(breadcrumbModule)
                .as("EPBDS-12366: Breadcrumb module must reflect the actual module of the opened table, not the previously selected module")
                .isEqualTo("AutoPolicyCalculation");
    }
}
