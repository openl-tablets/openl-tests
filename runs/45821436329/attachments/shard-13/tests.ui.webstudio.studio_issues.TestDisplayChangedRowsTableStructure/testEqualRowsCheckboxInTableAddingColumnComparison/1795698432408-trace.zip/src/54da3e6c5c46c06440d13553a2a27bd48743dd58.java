package tests.ui.webstudio.studio_issues;

import configuration.annotations.Description;
import configuration.annotations.TestCaseId;
import configuration.annotations.AppContainerConfig;
import configuration.appcontainer.AppContainerStartParameters;
import domain.serviceclasses.constants.User;
import domain.ui.webstudio.components.editortabcomponents.ChangesDialogComponent;
import domain.ui.webstudio.components.editortabcomponents.CompareLocalChangesDialogComponent;
import domain.ui.webstudio.components.editortabcomponents.leftmenu.EditorLeftRulesTreeComponent;
import domain.ui.webstudio.pages.mainpages.EditorPage;
import helpers.service.WorkflowService;
import org.testng.annotations.Test;
import tests.BaseTest;

import static domain.ui.webstudio.components.editortabcomponents.CompareLocalChangesDialogComponent.COMBINED;
import static org.assertj.core.api.Assertions.assertThat;
import static domain.ui.webstudio.components.editortabcomponents.leftmenu.TableTypeFolders.DECISION;

public class TestDisplayChangedRowsTableStructure extends BaseTest {

    @Test
    @TestCaseId("IPBQA-32105")
    @Description("Display Changed Rows: equal rows checkbox when a new table is created by copying a table with "
            + "merged cells (regression guard for EPBDS-16358).")
    @AppContainerConfig(startParams = AppContainerStartParameters.DEFAULT_STUDIO_PARAMS)
    public void testEqualRowsCheckboxInTableCreationComparison() {
        String projectName = WorkflowService.loginCreateProjectFromTemplate(User.ADMIN, "Example 1 - Bank Rating");
        EditorPage editorPage = new EditorPage();

        editorPage.getEditorLeftProjectModuleSelectorComponent()
                .selectModule(projectName, "Bank Rating");
        editorPage.getEditorLeftRulesTreeComponent()
                .setViewFilter(EditorLeftRulesTreeComponent.FilterOptions.BY_TYPE)
                .expandFolderInTree(DECISION)
                .selectItemInFolder(DECISION, "BankLimitIndex");

        editorPage.getEditorToolbarPanelComponent().copyTableAsNew("newTable", "");
        editorPage.waitUntilSpinnerLoaded();

        ChangesDialogComponent changesDialog = editorPage.getEditorToolbarPanelComponent()
                .clickMore()
                .clickChanges();

        changesDialog.setCompareCheckbox(1, true);
        changesDialog.setCompareCheckbox(2, true);
        CompareLocalChangesDialogComponent compareDialog = changesDialog.clickCompare();
        compareDialog.waitForDialogToAppear();

        compareDialog.openTreeNode("Limit");
        compareDialog.clickTreeNode("Rules Double newTable (Bank bank, RatingGroup bankRatingGroup)");

        compareDialog.setShowEqualRows(false);
        assertThat(compareDialog.getNumberOfRows(COMBINED))
                .as("The one table shows all 17 rows of the new table")
                .isEqualTo(17);
        assertThat(compareDialog.getHighlightedCellCount(COMBINED))
                .as("Every cell of the new table is marked as added in the one table")
                .isEqualTo(compareDialog.getNumberOfCells(COMBINED));
        compareDialog.showSideBySide();
        assertThat(compareDialog.getNumberOfRows(1))
                .as("Left fragment (original, no new table): 0 rows")
                .isEqualTo(0);
        assertThat(compareDialog.getNumberOfRows(2))
                .as("Right fragment (new table): 17 rows")
                .isEqualTo(17);

        compareDialog.setShowEqualRows(true);
        assertThat(compareDialog.getNumberOfRows(1))
                .as("Left fragment stays 0 (table didn't exist)")
                .isEqualTo(0);
        assertThat(compareDialog.getNumberOfRows(2))
                .as("Right fragment stays 17 rows")
                .isEqualTo(17);

        compareDialog.close();
    }

    @Test
    @TestCaseId("IPBQA-32105")
    @Description("Display Changed Rows: equal rows and column counts when both a row and a column are added")
    @AppContainerConfig(startParams = AppContainerStartParameters.DEFAULT_STUDIO_PARAMS)
    public void testEqualRowsCheckboxInTableAddingRowAndColumnComparison() {
        String projectName = WorkflowService.loginCreateProjectFromTemplate(User.ADMIN, "Sample Project");
        EditorPage editorPage = new EditorPage();

        editorPage.getEditorLeftProjectModuleSelectorComponent()
                .selectModule(projectName, "Main");
        editorPage.getEditorLeftRulesTreeComponent()
                .setViewFilter(EditorLeftRulesTreeComponent.FilterOptions.BY_TYPE)
                .expandFolderInTree(DECISION)
                .selectItemInFolder(DECISION, "Hello");

        editorPage.getEditorToolbarPanelComponent().getEditTableBtn().click();
        editorPage.getCenterTable().editCell(2, 1, "changedValue");
        editorPage.getCenterTable().clickCell(6, 4);
        editorPage.getEditorTableActionsPanelComponent().clickInsertColumnBefore();
        editorPage.getCenterTable().editCell(2, 4, "addedValue");
        editorPage.getEditorTableActionsPanelComponent().clickInsertRowAfter();
        editorPage.getCenterTable().editCell(3, 4, "addedValue2");
        editorPage.getEditorTableActionsPanelComponent().clickSaveChanges();

        ChangesDialogComponent changesDialog = editorPage.getEditorToolbarPanelComponent()
                .clickMore()
                .clickChanges();

        changesDialog.setCompareCheckbox(1, true);
        changesDialog.setCompareCheckbox(2, true);
        CompareLocalChangesDialogComponent compareDialog = changesDialog.clickCompare();
        compareDialog.waitForDialogToAppear();

        compareDialog.openTreeNode("Rules");
        compareDialog.clickTreeNode("Rules String Hello (Integer hour)");

        compareDialog.setShowEqualRows(false);
        assertThat(compareDialog.getNumberOfRows(COMBINED))
                .as("The one table: the 9 rows of the original and the added one")
                .isEqualTo(10);
        assertThat(compareDialog.getNumberOfColumns(COMBINED))
                .as("The one table: the 4 columns of the original and the added one")
                .isEqualTo(5);
        compareDialog.showSideBySide();
        assertThat(compareDialog.getNumberOfRows(1))
                .as("Left fragment (original): 9 rows")
                .isEqualTo(9);
        assertThat(compareDialog.getNumberOfColumns(1))
                .as("Left fragment (original): 4 columns")
                .isEqualTo(4);
        assertThat(compareDialog.getNumberOfRows(2))
                .as("Right fragment (with added row): 10 rows")
                .isEqualTo(10);
        assertThat(compareDialog.getNumberOfColumns(2))
                .as("Right fragment (with added column): 5 columns")
                .isEqualTo(5);

        compareDialog.setShowEqualRows(true);
        assertThat(compareDialog.getNumberOfRows(1))
                .as("Left fragment rows unchanged when showing equal rows (column added)")
                .isEqualTo(9);
        assertThat(compareDialog.getNumberOfColumns(1))
                .as("Left fragment columns unchanged")
                .isEqualTo(4);
        assertThat(compareDialog.getNumberOfRows(2))
                .as("Right fragment rows unchanged")
                .isEqualTo(10);
        assertThat(compareDialog.getNumberOfColumns(2))
                .as("Right fragment columns unchanged")
                .isEqualTo(5);

        compareDialog.close();
    }

    @Test
    @TestCaseId("IPBQA-32105")
    @Description("Display Changed Rows: equal rows and column counts when a column is added and written in")
    @AppContainerConfig(startParams = AppContainerStartParameters.DEFAULT_STUDIO_PARAMS)
    public void testEqualRowsCheckboxInTableAddingColumnComparison() {
        String projectName = WorkflowService.loginCreateProjectFromTemplate(User.ADMIN, "Sample Project");
        EditorPage editorPage = new EditorPage();

        editorPage.getEditorLeftProjectModuleSelectorComponent()
                .selectModule(projectName, "Main");
        editorPage.getEditorLeftRulesTreeComponent()
                .setViewFilter(EditorLeftRulesTreeComponent.FilterOptions.BY_TYPE)
                .expandFolderInTree(DECISION)
                .selectItemInFolder(DECISION, "Hello");

        editorPage.getEditorToolbarPanelComponent().getEditTableBtn().click();
        editorPage.getCenterTable().clickCell(2, 2);
        editorPage.getEditorTableActionsPanelComponent().clickInsertColumnBefore();
        editorPage.getCenterTable().editCell(2, 2, "addedValue");
        editorPage.getEditorTableActionsPanelComponent().clickSaveChanges();

        ChangesDialogComponent changesDialog = editorPage.getEditorToolbarPanelComponent()
                .clickMore()
                .clickChanges();

        changesDialog.setCompareCheckbox(1, true);
        changesDialog.setCompareCheckbox(2, true);
        CompareLocalChangesDialogComponent compareDialog = changesDialog.clickCompare();
        compareDialog.waitForDialogToAppear();

        compareDialog.openTreeNode("Rules");
        compareDialog.clickTreeNode("Rules String Hello (Integer hour)");

        compareDialog.setShowEqualRows(false);
        assertThat(compareDialog.getNumberOfRows(COMBINED))
                .as("The one table shows every row, since the added column runs through all of them")
                .isEqualTo(9);
        assertThat(compareDialog.getEqualRowsLeftOut(COMBINED))
                .as("A table with a column added leaves out no equal row")
                .isEmpty();
        compareDialog.showSideBySide();
        assertThat(compareDialog.getNumberOfRows(1))
                .as("Left fragment (original): every row, since the added column runs through all of them")
                .isEqualTo(9);
        assertThat(compareDialog.getEqualRowsLeftOut(1))
                .as("Left fragment leaves out no equal row of a table with a column added")
                .isEmpty();
        assertThat(compareDialog.getNumberOfColumns(1))
                .as("Left fragment (original): 4 columns")
                .isEqualTo(4);
        assertThat(compareDialog.getNumberOfRows(2))
                .as("Right fragment (column added): every row as well")
                .isEqualTo(9);
        assertThat(compareDialog.getNumberOfColumns(2))
                .as("Right fragment (column added): 5 columns")
                .isEqualTo(5);

        compareDialog.setShowEqualRows(true);
        assertThat(compareDialog.getNumberOfRows(1))
                .as("Left fragment: still all nine rows once the equal ones are asked for")
                .isEqualTo(9);
        assertThat(compareDialog.getNumberOfColumns(1))
                .as("Left fragment columns unchanged")
                .isEqualTo(4);
        assertThat(compareDialog.getNumberOfRows(2))
                .as("Right fragment: still all nine rows once the equal ones are asked for")
                .isEqualTo(9);
        assertThat(compareDialog.getNumberOfColumns(2))
                .as("Right fragment columns unchanged")
                .isEqualTo(5);

        compareDialog.close();
    }
}
