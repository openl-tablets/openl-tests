package domain.ui.webstudio.components.projectdetail;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import configuration.core.ui.WebElement;
import domain.ui.webstudio.components.BaseComponent;
import helpers.utils.WaitUtil;

import java.util.ArrayList;
import java.util.List;

public class ProjectOverviewTabComponent extends BaseComponent {

    private static final String DEFAULT_BRANCH_TAG = "Default";
    private static final int PROBE_MS = DEFAULT_TIMEOUT_MS / 5;
    private static final long MIGRATE_TIMEOUT_MS = 60000;

    private final WebElement branchLabel;
    private final WebElement branchSwitcherTrigger;
    private final WebElement branchMenuItem;
    private final WebElement modifiedValue;
    private final WebElement modifiedDate;
    private final WebElement tagValueForType;
    private final WebElement overviewRight;
    private final WebElement moduleRows;
    private final WebElement editBtn;
    private final WebElement saveBtn;
    private final WebElement descriptionInput;
    private final WebElement migrateBtn;
    private final WebElement migrateConfirmOkBtn;
    private final WebElement descriptorActionsMarker;
    private final WebElement matchedModuleToggles;
    private final WebElement matchedModuleRows;
    private final WebElement cancelBtn;
    private final WebElement openApiFileInput;
    private final WebElement openApiPathSelect;
    private final WebElement processorInput;
    private final WebElement addVersionPatternBtn;
    private final WebElement versionPatternField;
    private final WebElement editTagsBtn;
    private final WebElement saveTagsBtn;
    private final WebElement addTagBtn;
    private final WebElement tagKeyInput;
    private final WebElement tagValueInput;
    private final WebElement tagSuggestions;
    private final WebElement tagSuggestion;
    private final WebElement tagRows;
    private final WebElement openTagField;

    public ProjectOverviewTabComponent(Page page) {
        this(new WebElement(page, "xpath=//*[@data-testid='overview-panel']", "overviewPanel"));
    }

    public ProjectOverviewTabComponent(WebElement rootLocator) {
        super(rootLocator);
        branchLabel = createScopedElement("xpath=.//*[@data-testid='overview-branch']", "branchLabel");
        branchSwitcherTrigger = createScopedElement("xpath=.//*[@data-testid='overview-branch-trigger']", "branchSwitcherTrigger");
        branchMenuItem = new WebElement(page, "xpath=//div[contains(@class,'ant-dropdown')][not(contains(@class,'ant-dropdown-hidden'))]//li[contains(@class,'ant-dropdown-menu-item')][@data-menu-id='rc-menu-uuid-%s' or .//*[normalize-space()='%s']]", "branchMenuItem");
        modifiedValue = createScopedElement("xpath=.//*[@data-testid='overview-right']//div[./span[normalize-space()='Modified']]/following-sibling::div[1]", "modifiedValue");
        modifiedDate = createScopedElement("xpath=.//*[@data-testid='overview-right']//div[./span[normalize-space()='Modified']]/following-sibling::div[1]/div[last()]", "modifiedDate");
        tagValueForType = createScopedElement("xpath=.//*[@data-testid='project-tags']/span[normalize-space()='%s']/following-sibling::span[1]/span[1]", "tagValueForType");
        overviewRight = createScopedElement("xpath=.//*[@data-testid='overview-right']", "overviewRight");
        moduleRows = createScopedElement(
                "xpath=.//li[starts-with(@data-testid,'module-')]"
                        + "[not(starts-with(@data-testid,'module-filter-'))]"
                        + "[not(starts-with(@data-testid,'module-matched-'))]"
                        + "[not(starts-with(@data-testid,'module-unmatched-'))]",
                "overviewModuleRows");
        editBtn = createScopedElement("xpath=.//*[@data-testid='overview-edit']", "overviewEditBtn");
        saveBtn = createScopedElement("xpath=.//*[@data-testid='overview-save']", "overviewSaveBtn");
        descriptionInput = createScopedElement("xpath=.//*[@data-testid='edit-description']", "overviewDescriptionInput");
        migrateBtn = createScopedElement("xpath=.//*[@data-testid='overview-migrate']", "overviewMigrateBtn");
        migrateConfirmOkBtn = new WebElement(page,
                "xpath=//div[contains(@class,'ant-modal-confirm')]//div[contains(@class,'ant-modal-confirm-btns')]//button[contains(@class,'ant-btn-primary')]",
                "migrateConfirmOkBtn");
        descriptorActionsMarker = createScopedElement(
                "xpath=(.//*[@data-testid='overview-edit'] | .//*[@data-testid='overview-migrate'])[1]",
                "descriptorActionsMarker");
        matchedModuleToggles = createScopedElement(
                "xpath=.//button[starts-with(@data-testid,'module-matched-')]"
                        + "[not(starts-with(@data-testid,'module-matched-item-'))]",
                "matchedModuleToggles");
        matchedModuleRows = createScopedElement("xpath=.//li[starts-with(@data-testid,'module-matched-item-')]", "matchedModuleRows");
        cancelBtn = createScopedElement("xpath=.//*[@data-testid='overview-cancel']", "overviewCancelBtn");
        openApiFileInput = createScopedElement("xpath=.//*[@data-testid='edit-openapi-upload']/ancestor::span[1]//input[@type='file']", "openApiFileInput");
        openApiPathSelect = createScopedElement("xpath=.//*[@data-testid='edit-openapi-path']", "openApiPathSelect");
        processorInput = createScopedElement("xpath=.//*[@data-testid='edit-processor']", "processorInput");
        addVersionPatternBtn = createScopedElement("xpath=.//*[@data-testid='edit-version-pattern-add']", "addVersionPatternBtn");
        versionPatternField = createScopedElement("xpath=.//input[@data-testid='edit-version-pattern-0']", "versionPatternField");
        editTagsBtn = createScopedElement("xpath=.//*[@data-testid='edit-tags']", "editTagsBtn");
        saveTagsBtn = createScopedElement("xpath=.//*[@data-testid='tags-save']", "saveTagsBtn");
        addTagBtn = createScopedElement("xpath=.//*[@data-testid='edit-tag-add']", "addTagBtn");
        tagKeyInput = createScopedElement("xpath=.//*[@data-testid='edit-tag-%s']//input", "tagKeyInput");
        tagValueInput = createScopedElement("xpath=.//*[@data-testid='edit-tag-%s-value']//input", "tagValueInput");
        tagSuggestions = new WebElement(page,
                "xpath=//div[contains(concat(' ',normalize-space(@class),' '),' ant-select-dropdown ')][.//div[@id='%s']]"
                        + "//div[contains(concat(' ',normalize-space(@class),' '),' ant-select-item-option ')]",
                "tagSuggestions");
        tagSuggestion = new WebElement(page,
                "xpath=//div[contains(concat(' ',normalize-space(@class),' '),' ant-select-dropdown ')][.//div[@id='%s']]"
                        + "//div[contains(concat(' ',normalize-space(@class),' '),' ant-select-item-option ')][@title='%s']",
                "tagSuggestion");
        tagRows = createScopedElement("xpath=.//*[starts-with(@data-testid,'edit-tag-')][substring(@data-testid,string-length(@data-testid)-3)='-row']", "tagRows");
        openTagField = createScopedElement("xpath=.//*[@data-testid='project-tags-editor']//input[@aria-expanded='true']", "openTagField");
    }

    public String getCurrentBranch() {
        String label = branchLabel.getText().trim();
        if (label.endsWith(DEFAULT_BRANCH_TAG)) {
            label = label.substring(0, label.length() - DEFAULT_BRANCH_TAG.length());
        }
        return label.trim();
    }

    public void switchBranch(String branchName) {
        chooseBranch(branchName);
        waitUntilSpinnerLoaded();
    }

    public void chooseBranch(String branchName) {
        branchSwitcherTrigger.click();
        branchMenuItem.format(branchName, branchName).click();
    }

    public boolean isBranchSwitching() {
        return Boolean.parseBoolean(branchSwitcherTrigger.getAttribute("aria-busy"));
    }

    public boolean isBranchPresent(String branchName) {
        if (branchName.equals(getCurrentBranch())) {
            return true;
        }
        branchSwitcherTrigger.click();
        boolean present = branchMenuItem.format(branchName, branchName).isVisible(PROBE_MS);
        page.keyboard().press("Escape");
        return present;
    }

    public void startEditingTags() {
        editTagsBtn.click();
        addTagBtn.waitForVisible(DEFAULT_TIMEOUT_MS);
    }

    public int addTagRow() {
        int rows = tagRows.getLocator().count();
        addTagBtn.click();
        tagKeyInput.format(rows).waitForVisible(DEFAULT_TIMEOUT_MS);
        return rows;
    }

    public void saveTags() {
        saveTagsBtn.click();
        addTagBtn.waitForHidden(DEFAULT_TIMEOUT_MS);
    }

    public List<String> getTagKeySuggestions(int row) {
        return suggestionsOf(tagKeyInput.format(row));
    }

    public List<String> getTagValueSuggestions(int row) {
        return suggestionsOf(tagValueInput.format(row));
    }

    public List<String> typeTagKey(int row, String text) {
        return typeInto(tagKeyInput.format(row), text);
    }

    public List<String> typeTagValue(int row, String text) {
        return typeInto(tagValueInput.format(row), text);
    }

    public void pickTagSuggestion(String text) {
        String listId = openTagField.getAttribute("aria-controls");
        tagSuggestion.format(listId, text).click();
    }

    public void closeTagSuggestions(int row) {
        WebElement key = tagKeyInput.format(row);
        if ("true".equals(key.getAttribute("aria-expanded"))) {
            key.press("Escape");
        }
    }

    private List<String> suggestionsOf(WebElement field) {
        if (!"true".equals(field.getAttribute("aria-expanded"))) {
            field.click();
        }
        return readSuggestions(field);
    }

    private List<String> typeInto(WebElement field, String text) {
        field.click();
        field.fill("");
        field.fillSequentially(text);
        return readSuggestions(field);
    }

    private List<String> readSuggestions(WebElement field) {
        WebElement suggestions = tagSuggestions.format(field.getAttribute("aria-controls"));
        suggestions.getLocator().first().waitFor();
        List<List<String>> reads = new ArrayList<>(List.of(List.of()));
        WaitUtil.waitForCondition(() -> {
            List<String> current = readNames(suggestions);
            boolean settled = current.equals(reads.getLast());
            reads.add(current);
            return settled;
        }, DEFAULT_TIMEOUT_MS, 300, "Waiting for the tag suggestions to settle");
        return reads.getLast();
    }

    private List<String> readNames(WebElement options) {
        Locator found = options.getLocator();
        List<String> names = new ArrayList<>();
        for (int i = 0; i < found.count(); i++) {
            names.add(found.nth(i).innerText().trim());
        }
        return names;
    }

    public String getTagValueForType(String tagType) {
        return tagValueForType.format(tagType).getText().trim();
    }

    public String extractField(String label, String nextLabel) {
        String blob = overviewRight.getText();
        int start = blob.indexOf(label);
        if (start < 0) {
            return "";
        }
        start += label.length();
        int end = blob.indexOf(nextLabel, start);
        return (end < 0 ? blob.substring(start) : blob.substring(start, end)).trim();
    }

    public List<String> getModuleNames() {
        descriptorActionsMarker.waitForVisible(DEFAULT_TIMEOUT_MS);
        Locator rows = moduleRows.getLocator();
        List<String> names = new ArrayList<>();
        for (int i = 0; i < rows.count(); i++) {
            names.add(rows.nth(i).innerText().trim().split("\n")[0].trim());
        }
        return names;
    }

    public List<String> getMatchedModuleNames() {
        descriptorActionsMarker.waitForVisible(DEFAULT_TIMEOUT_MS);
        Locator toggles = matchedModuleToggles.getLocator();
        for (int i = 0; i < toggles.count(); i++) {
            Locator toggle = toggles.nth(i);
            if ("false".equals(toggle.getAttribute("aria-expanded"))) {
                toggle.click();
            }
        }
        Locator rows = matchedModuleRows.getLocator();
        List<String> names = new ArrayList<>();
        for (int i = 0; i < rows.count(); i++) {
            names.add(rows.nth(i).innerText().trim().split("\n")[0].trim());
        }
        return names;
    }

    public void renameDeclaredModule(String moduleName, String newName) {
        openForWriting();
        WebElement field = declaredModuleField(moduleName);
        field.fill(newName);
        keepWhatWasWritten();
    }

    public void addDeclaredModule(String moduleName, String path) {
        writeANewModuleRow(moduleName, path);
        keepWhatWasWritten();
    }

    public String addDeclaredModuleExpectingRefusal(String moduleName, String path) {
        writeANewModuleRow(moduleName, path);
        saveBtn.waitForVisible(DEFAULT_TIMEOUT_MS).click();
        return whyTheCardRefused();
    }

    private void writeANewModuleRow(String moduleName, String path) {
        openForWriting();
        int standing = declaredModuleFields().size();
        new WebElement(page, "xpath=//*[@data-testid='edit-module-add']", "addModuleRow")
                .waitForVisible(DEFAULT_TIMEOUT_MS).click();
        WaitUtil.requireCondition(() -> declaredModuleFields().size() > standing, DEFAULT_TIMEOUT_MS, 200,
                "Waiting for the card to draw the module row it was asked for");
        new WebElement(page, "xpath=//*[@data-testid='edit-module-" + standing + "']", "newModuleName")
                .waitForVisible(DEFAULT_TIMEOUT_MS).fill(moduleName);
        new WebElement(page, "xpath=//*[@data-testid='edit-module-" + standing + "-path']", "newModulePath")
                .waitForVisible(DEFAULT_TIMEOUT_MS).fill(path);
    }

    public void removeDeclaredModule(String moduleName) {
        openForWriting();
        int row = declaredModuleRowOf(moduleName);
        new WebElement(page, "xpath=//*[@data-testid='edit-module-" + row + "-remove']", "removeModuleRow")
                .waitForVisible(DEFAULT_TIMEOUT_MS).click();
        keepWhatWasWritten();
    }

    public String whyTheCardRefused() {
        WebElement refusal = new WebElement(page,
                "xpath=(//div[contains(concat(' ',normalize-space(@class),' '),' ant-notification-notice-wrapper ')])"
                        + "[last()]", "cardRefusal");
        return refusal.isVisible(DEFAULT_TIMEOUT_MS / 4) ? refusal.getInnerText().trim().replace("\n", " ") : "";
    }

    public void openForWriting() {
        if (saveBtn.isVisible(DEFAULT_TIMEOUT_MS / 5)) {
            return;
        }
        editBtn.waitForVisible(DEFAULT_TIMEOUT_MS).click();
        saveBtn.waitForVisible(DEFAULT_TIMEOUT_MS);
    }

    private void keepWhatWasWritten() {
        saveBtn.waitForVisible(DEFAULT_TIMEOUT_MS).click();
        waitUntilSpinnerLoaded();
    }

    private List<WebElement> declaredModuleFields() {
        return createElementList("xpath=//input[starts-with(@data-testid,'edit-module-')]"
                + "[not(contains(@data-testid,'-path'))][not(contains(@data-testid,'-compile-only'))]",
                "declaredModuleNames");
    }

    private WebElement declaredModuleField(String moduleName) {
        return new WebElement(page,
                "xpath=//input[starts-with(@data-testid,'edit-module-')][not(contains(@data-testid,'-path'))]"
                        + "[not(contains(@data-testid,'-compile-only'))][@value=\"" + moduleName + "\"]",
                "declaredModuleName").waitForVisible(DEFAULT_TIMEOUT_MS);
    }

    private int declaredModuleRowOf(String moduleName) {
        List<WebElement> fields = declaredModuleFields();
        for (int row = 0; row < fields.size(); row++) {
            if (moduleName.equals(fields.get(row).getCurrentInputValue())) {
                return row;
            }
        }
        throw new AssertionError("The card declares no module named '" + moduleName + "'");
    }

    public String moduleMethodFilter(String modulePath) {
        descriptorActionsMarker.waitForVisible(DEFAULT_TIMEOUT_MS);
        WebElement filter = new WebElement(page,
                "xpath=//*[@data-testid='module-filter-" + modulePath + "']", "moduleMethodFilter");
        return filter.isVisible(DEFAULT_TIMEOUT_MS) ? filter.getInnerText().trim().replace("\n", " ") : "";
    }

    public void cancelEditing() {
        cancelBtn.waitForVisible(DEFAULT_TIMEOUT_MS).click();
        editBtn.waitForVisible(DEFAULT_TIMEOUT_MS);
    }

    public boolean isEditing() {
        return saveBtn.isVisible(PROBE_MS);
    }

    public boolean isEditEndedWithin(long timeoutMs) {
        return WaitUtil.waitForCondition(() -> !saveBtn.isVisible(PROBE_MS), timeoutMs, PROBE_MS,
                "Waiting to see whether the Overview edit ends by itself");
    }

    public void pickOpenApiFile(String filePath) {
        openApiFileInput.setInputFiles(filePath);
    }

    public String getPickedOpenApiPath() {
        return openApiPathSelect.waitForVisible(DEFAULT_TIMEOUT_MS).getText().trim();
    }

    public void setPropertiesProcessor(String processor) {
        processorInput.waitForVisible(DEFAULT_TIMEOUT_MS).fill(processor);
    }

    public void setVersionPattern(String pattern) {
        WaitUtil.requireCondition(() -> versionPatternField.isVisible(PROBE_MS) || addVersionPatternBtn.isVisible(PROBE_MS),
                DEFAULT_TIMEOUT_MS, PROBE_MS, "Waiting for the version pattern row or the button adding it");
        if (!versionPatternField.isVisible(PROBE_MS)) {
            addVersionPatternBtn.click();
        }
        versionPatternField.waitForVisible(DEFAULT_TIMEOUT_MS).fill(pattern);
    }

    public String saveExpectingRefusal() {
        String previous = whyTheCardRefused();
        saveBtn.waitForVisible(DEFAULT_TIMEOUT_MS).click();
        String[] latest = {""};
        WaitUtil.waitForCondition(() -> {
            latest[0] = whyTheCardRefused();
            return !latest[0].isEmpty() && !latest[0].equals(previous);
        }, DEFAULT_TIMEOUT_MS, PROBE_MS, "Waiting for the card to raise a new refusal");
        return latest[0];
    }

    public void editAndSave() {
        editBtn.waitForVisible(DEFAULT_TIMEOUT_MS).click();
        saveBtn.waitForVisible(DEFAULT_TIMEOUT_MS).click();
        waitUntilSpinnerLoaded();
    }

    public void editDescriptionAndSave(String description) {
        editBtn.waitForVisible(DEFAULT_TIMEOUT_MS).click();
        descriptionInput.waitForVisible(DEFAULT_TIMEOUT_MS).fill(description);
        saveBtn.waitForVisible(DEFAULT_TIMEOUT_MS).click();
        waitUntilSpinnerLoaded();
    }

    public void migrateAndWaitUntilEditable() {
        migrateBtn.waitForVisible(DEFAULT_TIMEOUT_MS).click();
        migrateConfirmOkBtn.waitForVisible(DEFAULT_TIMEOUT_MS).click();
        WaitUtil.requireCondition(() -> !migrateConfirmOkBtn.isVisible(PROBE_MS), MIGRATE_TIMEOUT_MS, 250,
                "Waiting for the move of the descriptor to be made");
        WaitUtil.requireCondition(() -> !migrateBtn.isVisible(PROBE_MS), MIGRATE_TIMEOUT_MS, 250,
                "Waiting for the card to stop offering a move it has already made");
        editBtn.waitForVisible(DEFAULT_TIMEOUT_MS);
        waitUntilSpinnerLoaded();
    }

    public boolean isMigrateOffered() {
        return migrateBtn.isVisible(DEFAULT_TIMEOUT_MS / 2);
    }

    public boolean isEditOffered() {
        return editBtn.isVisible(DEFAULT_TIMEOUT_MS / 2);
    }

    public boolean isMigrateEnabled() {
        migrateBtn.waitForVisible(DEFAULT_TIMEOUT_MS);
        return migrateBtn.isEnabled();
    }

    public List<String> getDependencyNames(String section) {
        dependencyRows(section).first().waitFor();
        List<String> names = readDependencyNames(section);
        WaitUtil.waitForCondition(() -> {
            List<String> again = readDependencyNames(section);
            boolean stable = again.equals(names);
            names.clear();
            names.addAll(again);
            return stable;
        }, DEFAULT_TIMEOUT_MS, PROBE_MS, "Waiting for the " + section + " list to stop changing");
        return names;
    }

    private List<String> readDependencyNames(String section) {
        List<String> names = new ArrayList<>();
        for (Locator row : dependencyRows(section).all()) {
            names.add(row.locator("xpath=./*[1]").innerText().trim());
        }
        return names;
    }

    public String getDependencyRowText(String section, String name) {
        Locator row = dependencyRows(section).filter(new Locator.FilterOptions()
                .setHas(page.locator("xpath=./*[1][normalize-space()=\"" + name + "\"]")));
        return row.first().innerText().trim().replaceAll("\\s+", " ");
    }

    public void openDependency(String name) {
        dependencyRows("Depends on").locator("xpath=./a[normalize-space()=\"" + name + "\"]").click();
    }

    private Locator dependencyRows(String section) {
        return page.locator("xpath=//*[@data-testid='overview-left']//span[normalize-space()='" + section
                + "']/following-sibling::ul[1]/li");
    }

    public String getModifiedBy() {
        String whole = modifiedValue.getText().trim();
        String date = modifiedDate.getText().trim();
        return whole.endsWith(date) ? whole.substring(0, whole.length() - date.length()).trim() : whole;
    }

    public String getModifiedAt() {
        return modifiedDate.getText().trim();
    }
}
