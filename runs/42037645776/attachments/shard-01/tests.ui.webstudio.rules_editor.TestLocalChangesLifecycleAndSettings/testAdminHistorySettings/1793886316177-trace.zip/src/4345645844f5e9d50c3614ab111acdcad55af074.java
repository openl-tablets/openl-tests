package domain.ui.webstudio.components.admincomponents;

import domain.ui.webstudio.components.BaseComponent;
import configuration.core.ui.WebElement;
import configuration.driver.DriverPool;
import lombok.Getter;

public class AdminNavigationComponent extends BaseComponent {

    private WebElement navigationItemTemplate;

    public AdminNavigationComponent() {
        super(DriverPool.getPage());
        initializeNavigationComponents();
    }

    public AdminNavigationComponent(WebElement rootLocator) {
        super(rootLocator);
        initializeNavigationComponents();
    }

    private void initializeNavigationComponents() {
        navigationItemTemplate = createScopedElement("xpath=.//li[contains(@class,'ant-menu-item') and ./span[text()='%s']]", "navigationItem");
    }

    public void clickNavigationItem(NavigationItem item) {
        navigationItemTemplate.format(item.getValue()).click();
    }

    public void clickMyProfile() {
        clickNavigationItem(NavigationItem.MY_PROFILE);
    }

    public void clickRepositories() {
        clickNavigationItem(NavigationItem.REPOSITORIES);
    }

    public void clickSystem() {
        clickNavigationItem(NavigationItem.SYSTEM);
    }

    public void clickSecurity() {
        clickNavigationItem(NavigationItem.SECURITY);
    }

    public void clickUsers() {
        clickNavigationItem(NavigationItem.USERS);
    }

    public void clickMail() {
        clickNavigationItem(NavigationItem.MAIL);
    }

    public void clickNotification() {
        clickNavigationItem(NavigationItem.NOTIFICATION);
    }

    public void clickTags() {
        clickNavigationItem(NavigationItem.TAGS);
    }

    public void clickPersonalAccessTokens() {
        clickNavigationItem(NavigationItem.PERSONAL_ACCESS_TOKENS);
    }

    public void clickAuditLog() {
        clickNavigationItem(NavigationItem.AUDIT_LOG);
    }

    @Getter
    public enum NavigationItem {
        MY_PROFILE("My Profile"),
        REPOSITORIES("Repositories"),
        SYSTEM("System"),
        SECURITY("Security"),
        USERS("Users"),
        MAIL("Mail"),
        NOTIFICATION("Notification"),
        TAGS("Tags"),
        PERSONAL_ACCESS_TOKENS("Personal Access Tokens"),
        AUDIT_LOG("Audit Log");

        private final String value;

        NavigationItem(String value) {
            this.value = value;
        }
    }
}