package tests.ui.webstudio.rules_editor;

import configuration.annotations.Description;
import configuration.annotations.TestCaseId;
import configuration.annotations.AppContainerConfig;
import configuration.appcontainer.AppContainerStartParameters;
import configuration.driver.DriverPool;
import domain.serviceclasses.constants.User;
import domain.ui.webstudio.components.common.TableComponent;
import domain.ui.webstudio.components.common.TabSwitcherComponent;
import domain.ui.webstudio.components.editortabcomponents.leftmenu.EditorLeftRulesTreeComponent;
import domain.ui.webstudio.pages.mainpages.EditorPage;
import domain.ui.webstudio.pages.mainpages.ProjectDetailPage;
import domain.ui.webstudio.pages.mainpages.RepositoryPage;
import helpers.service.LoginService;
import helpers.service.UserService;
import helpers.utils.TestDataUtil;
import helpers.utils.ZipUtil;
import org.testng.annotations.Test;
import tests.BaseTest;

import java.io.File;

import static org.assertj.core.api.Assertions.assertThat;
import static domain.ui.webstudio.components.editortabcomponents.leftmenu.TableTypeFolders.CONFIGURATION;

public class TestCreateProjectFromOpenApiJsonFile extends BaseTest {

    private static final String JSON_FILE = "openapi.json";

    @Test
    @TestCaseId("IPBQA-30678")
    @Description("Create project from OpenAPI JSON file and verify repository tree structure and Editor module properties;"
            + " copying a module keeps the modules the descriptor already declares (EPBDS-16227) and an uploaded"
            + " workbook does not rewrite an explicit rules.xml.")
    @AppContainerConfig(startParams = AppContainerStartParameters.DEFAULT_STUDIO_PARAMS)
    public void testCreateProjectFromOpenApiJsonFile() {
        String projectName = "JsonOpenApiProject_" + System.currentTimeMillis();

        LoginService loginService = new LoginService(DriverPool.getPage());
        EditorPage editorPage = loginService.login(UserService.getUser(User.ADMIN));

        RepositoryPage repositoryPage = editorPage.getTabSwitcherComponent()
                .selectTab(TabSwitcherComponent.TabName.REPOSITORY);

        repositoryPage.createProjectFromOpenApi(JSON_FILE, projectName);

        ProjectDetailPage projectDetail = repositoryPage.openProjectDetail(projectName).openFilesTab();
        assertThat(projectDetail.isFilePresent("Algorithms.xlsx"))
                .as("Algorithms.xlsx should be present in the project files").isTrue();
        assertThat(projectDetail.isFilePresent("Models.xlsx"))
                .as("Models.xlsx should be present in the project files").isTrue();
        assertThat(projectDetail.isFilePresent("openapi.json"))
                .as("openapi.json should be present in the project files").isTrue();
        assertThat(projectDetail.isFilePresent("rules.xml"))
                .as("rules.xml should be present in the project files").isTrue();
        assertThat(projectDetail.isFilePresent("rules-deploy.xml"))
                .as("rules-deploy.xml should be present in the project files").isTrue();
        repositoryPage.openProjectsList();

        editorPage = new EditorPage();
        editorPage.getEditorLeftProjectModuleSelectorComponent().selectProject(projectName);

        assertThat(editorPage.getOpenApiPropertyValue("File"))
                .as("OpenAPI File property should reflect uploaded file name").isEqualTo("openapi.json");
        assertThat(editorPage.getOpenApiMode())
                .as("A project created from a specification is reconciled against it").isEqualTo("Reconciliation");
        assertThat(editorPage.hasOpenApiProperty("Services module"))
                .as("No module is named to write the rules into until a generation is asked for").isFalse();
        assertThat(editorPage.hasOpenApiProperty("Data types module"))
                .as("No module is named to write the data types into until a generation is asked for").isFalse();

        editorPage.getEditorLeftProjectModuleSelectorComponent().selectModule(projectName, "Algorithms");
        editorPage.getEditorLeftRulesTreeComponent().setViewFilter(EditorLeftRulesTreeComponent.FilterOptions.BY_TYPE);
        assertThat(editorPage.getEditorLeftRulesTreeComponent().isFolderExistsInTree("Spreadsheet"))
                .as("Algorithms module should have Spreadsheet folder").isTrue();
        assertThat(editorPage.getEditorLeftRulesTreeComponent().isFolderExistsInTree(CONFIGURATION))
                .as("Algorithms module should have Configuration folder").isTrue();
        assertThat(editorPage.getEditorLeftRulesTreeComponent().isFolderExistsInTree("Datatype"))
                .as("Algorithms module should NOT have Datatype folder").isFalse();
        editorPage.getProblemsPanelComponent().checkNoProblems();

        editorPage.getEditorToolbarPanelComponent().navigateToProjectRoot(projectName);
        editorPage.getEditorLeftProjectModuleSelectorComponent().selectModule(projectName, "Models");
        editorPage.getEditorLeftRulesTreeComponent().setViewFilter(EditorLeftRulesTreeComponent.FilterOptions.BY_TYPE);
        assertThat(editorPage.getEditorLeftRulesTreeComponent().isFolderExistsInTree("Datatype"))
                .as("Models module should have Datatype folder").isTrue();
        assertThat(editorPage.getEditorLeftRulesTreeComponent().isFolderExistsInTree("Spreadsheet"))
                .as("Models module should NOT have Spreadsheet folder").isFalse();
        editorPage.getProblemsPanelComponent().checkNoProblems();

        editorPage.getEditorLeftRulesTreeComponent().expandFolderInTree("Datatype");
        editorPage.getEditorLeftRulesTreeComponent().selectItemInFolder("Datatype", "JAXRSErrorResponse");
        TableComponent datatypeTable = editorPage.getCenterTable();
        editorPage.getEditorToolbarPanelComponent().getEditTableBtn().click();
        datatypeTable.editCell(3, 1, "String[]");
        editorPage.getEditorTableActionsPanelComponent().clickSaveChanges();
        editorPage.waitUntilSpinnerLoaded();
        editorPage.waitUntilAppIdle();
        editorPage.getProblemsPanelComponent().checkNoProblems();

        editorPage.reloadPage();
        editorPage.getTabSwitcherComponent().selectTab(TabSwitcherComponent.TabName.REPOSITORY);
        editorPage = new EditorPage();
        editorPage.getEditorLeftProjectModuleSelectorComponent().selectProject(projectName);

        editorPage.getEditorToolbarPanelComponent().clickExport();
        File exportedZip = editorPage.getExportProjectDialogComponent().clickExportAndDownload();

        String deployXml = ZipUtil.readFileFromZip(exportedZip, "rules-deploy.xml");
        assertThat(deployXml).as("rules-deploy.xml should contain isProvideRuntimeContext=true")
                .contains("<isProvideRuntimeContext>true</isProvideRuntimeContext>");
        assertThat(deployXml).as("rules-deploy.xml should contain RESTFUL publisher")
                .contains("<publisher>RESTFUL</publisher>");
        assertThat(deployXml).as("rules-deploy.xml should contain annotationTemplateClassName")
                .contains("<annotationTemplateClassName>org.openl.generated.services.Service</annotationTemplateClassName>");

        String rulesXml = ZipUtil.readFileFromZip(exportedZip, "rules.xml");
        assertThat(rulesXml).as("The descriptor repeats neither module, which the standard layout finds")
                .doesNotContain("<modules>").doesNotContain("<rules-root");
        assertThat(rulesXml).as("The descriptor holds no generation settings, so later edits are not written over")
                .doesNotContain("<openapi>");
        assertThat(editorPage.getEditorLeftProjectModuleSelectorComponent().getAllModuleNames(projectName))
                .as("Both generated modules are read all the same")
                .containsExactlyInAnyOrder("Algorithms", "Models");

        editorPage.renameModuleWorkbook(projectName, "Algorithms.xlsx", "Algorithms_test.xlsx");
        editorPage.renameModuleWorkbook(projectName, "Models.xlsx", "Models_test.xlsx");
        assertThat(editorPage.getEditorLeftProjectModuleSelectorComponent().getAllModuleNames(projectName))
                .as("A module renamed with its workbook is read under the new name")
                .containsExactlyInAnyOrder("Algorithms_test", "Models_test");

        editorPage.copyModuleWorkbook(projectName, "Algorithms_test.xlsx", "Algorithms2.xlsx");
        assertThat(editorPage.getEditorLeftProjectModuleSelectorComponent().getAllModuleNames(projectName))
                .as("Copying a module must add it next to the modules the project already reads (EPBDS-16227)")
                .containsExactlyInAnyOrder("Algorithms2", "Algorithms_test", "Models_test");

        editorPage.getEditorToolbarPanelComponent().clickExport();
        String rulesXmlAfterCopy = ZipUtil.readFileFromZip(
                editorPage.getExportProjectDialogComponent().clickExportAndDownload(), "rules.xml");

        repositoryPage = editorPage.getTabSwitcherComponent().selectTab(TabSwitcherComponent.TabName.REPOSITORY);
        ProjectDetailPage detailAfterUpload = repositoryPage.openProjectsList().openProjectDetail(projectName);
        detailAfterUpload.uploadFileInto(TestDataUtil.getFilePathFromResources("rules.xlsx"), "rules");
        assertThat(detailAfterUpload.isFilePresent("rules.xlsx"))
                .as("rules.xlsx should be present in the project files after upload").isTrue();
        repositoryPage.openProjectsList().saveProject(projectName, "Uploaded rules.xlsx");

        EditorPage editorPageAfterUpload = new EditorPage();
        editorPageAfterUpload.getEditorLeftProjectModuleSelectorComponent().selectProject(projectName);
        assertThat(editorPageAfterUpload.getEditorLeftProjectModuleSelectorComponent().getAllModuleNames(projectName))
                .as("A workbook put in the rules folder is read as a module of its own, and the ones already "
                        + "there are kept")
                .containsExactlyInAnyOrder("Algorithms2", "Algorithms_test", "Models_test", "rules");

        editorPageAfterUpload.getEditorToolbarPanelComponent().clickExport();
        File exportedZipAfterUpload = editorPageAfterUpload.getExportProjectDialogComponent().clickExportAndDownload();
        String rulesXmlAfterUpload = ZipUtil.readFileFromZip(exportedZipAfterUpload, "rules.xml");
        assertThat(rulesXmlAfterUpload)
                .as("The descriptor is left as the copy left it: an upload writes no module into it")
                .isEqualTo(rulesXmlAfterCopy);
        assertThat(rulesXmlAfterUpload)
                .as("The descriptor declares no module of its own through all of this")
                .doesNotContain("<modules>").doesNotContain("<rules-root");
        assertThat(ZipUtil.listFiles(exportedZipAfterUpload))
                .as("The saved project holds the workbooks as they were renamed, copied and uploaded")
                .contains("rules/Algorithms_test.xlsx", "rules/Algorithms2.xlsx", "rules/Models_test.xlsx",
                        "rules/rules.xlsx");

        repositoryPage = editorPageAfterUpload.getTabSwitcherComponent()
                .selectTab(TabSwitcherComponent.TabName.REPOSITORY);
        repositoryPage.openProjectsList().copyProject(projectName, projectName + "-Copy");
        assertThat(repositoryPage.isProjectPresent(projectName + "-Copy"))
                .as("Copied project '" + projectName + "-Copy' should appear in the projects list").isTrue();
    }
}
