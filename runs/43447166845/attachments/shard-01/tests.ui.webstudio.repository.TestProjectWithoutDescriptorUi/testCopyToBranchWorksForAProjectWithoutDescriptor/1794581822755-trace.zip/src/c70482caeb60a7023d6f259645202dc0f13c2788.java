package domain.ui.webstudio.components.projectdetail;

import com.microsoft.playwright.Page;
import configuration.core.ui.WebElement;
import domain.ui.webstudio.components.BaseComponent;
import domain.ui.webstudio.components.common.HeaderSearchComponent;
import helpers.utils.WaitUtil;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ProjectFilesTabComponent extends BaseComponent {

    private static final int FILE_DIALOG_TIMEOUT_MS = DEFAULT_TIMEOUT_MS * 3;
    private static final int TREE_LOAD_TIMEOUT_MS = DEFAULT_TIMEOUT_MS * 6;
    private static final Pattern FILE_PARAM = Pattern.compile("[?&]file=([^&#]*)");

    private final WebElement fileNodeByName;
    private final WebElement addBtn;
    private final WebElement fileActionsBtn;
    private final WebElement addMenuItem;
    private final WebElement fileActionsMenuItem;
    private final WebElement fileDeleteSubmitBtn;
    private final WebElement updateFileInput;
    private final WebElement updateFileSubmitBtn;
    private final WebElement updateFileNameWarning;
    private final WebElement uploadInput;
    private final WebElement uploadNameField;
    private final WebElement uploadPathField;
    private final WebElement uploadSubmitBtn;
    private final WebElement folderPathInput;
    private final WebElement folderSubmitBtn;
    private final WebElement filePreviewEmpty;
    private final WebElement filePreviewError;
    private final WebElement filePaneLoading;
    private final HeaderSearchComponent filesSearch;

    public ProjectFilesTabComponent(Page page) {
        this(new WebElement(page, "xpath=//*[@data-testid='project-detail']", "projectDetail"));
    }

    public ProjectFilesTabComponent(WebElement rootLocator) {
        super(rootLocator);
        fileNodeByName = createScopedElement("xpath=.//div[@role='treeitem'][.//*[normalize-space()='%s']]", "fileTreeNode");
        addBtn = createScopedElement("xpath=.//*[@data-testid='files-add']", "filesAddBtn");
        fileActionsBtn = createScopedElement("xpath=.//*[@data-testid='file-actions']", "fileActionsBtn");
        addMenuItem = new WebElement(page, "xpath=//div[contains(@class,'ant-dropdown')][not(contains(@class,'ant-dropdown-hidden'))]//li[contains(@class,'ant-dropdown-menu-item')][.//span[@data-testid='%s']]", "filesAddMenuItem");
        fileActionsMenuItem = new WebElement(page, "xpath=//div[contains(@class,'ant-dropdown')][not(contains(@class,'ant-dropdown-hidden'))]//li[contains(@class,'ant-dropdown-menu-item')][normalize-space()='%s']", "fileActionsMenuItem");
        fileDeleteSubmitBtn = new WebElement(page, "xpath=//*[@data-testid='file-delete-submit']", "fileDeleteSubmitBtn");
        updateFileInput = new WebElement(page, "xpath=//input[@data-testid='update-file-dragger']", "updateFileInput");
        updateFileSubmitBtn = new WebElement(page, "xpath=//*[@data-testid='update-file-submit']", "updateFileSubmitBtn");
        updateFileNameWarning = new WebElement(page, "xpath=//*[@data-testid='update-file-name-warning']", "updateFileNameWarning");
        uploadInput = new WebElement(page, "xpath=//input[@data-testid='files-upload-dragger']", "filesUploadInput");
        uploadNameField = new WebElement(page, "xpath=//*[@data-testid='files-upload-name']", "filesUploadNameField");
        uploadPathField = new WebElement(page, "xpath=//*[@data-testid='files-upload-path']//input", "filesUploadPathField");
        uploadSubmitBtn = new WebElement(page, "xpath=//*[@data-testid='files-upload-submit']", "filesUploadSubmitBtn");
        folderPathInput = new WebElement(page, "xpath=//*[@data-testid='files-folder-path']//input", "folderPathInput");
        folderSubmitBtn = new WebElement(page, "xpath=//*[@data-testid='files-folder-submit']", "folderSubmitBtn");
        filePreviewEmpty = createScopedElement("xpath=.//*[@data-testid='file-preview-empty']", "filePreviewEmpty");
        filePreviewError = createScopedElement("xpath=.//*[@data-testid='file-preview-error']", "filePreviewError");
        filePaneLoading = createScopedElement("xpath=.//*[@data-testid='file-pane-loading']", "filePaneLoading");
        filesSearch = new HeaderSearchComponent(page, HeaderSearchComponent.Scope.FILES);
    }

    public boolean isOpen(int timeoutInMillis) {
        return filesSearch.isOffered(timeoutInMillis);
    }

    public void waitForOpen(int timeoutInMillis) {
        filesSearch.waitForOffered(timeoutInMillis);
    }

    public void deleteFile(String fileName) {
        fileNodeByName.format(fileName).click();
        fileActionsBtn.waitForVisible(DEFAULT_TIMEOUT_MS).click();
        fileActionsMenuItem.format("Delete").click();
        fileDeleteSubmitBtn.click();
        waitUntilSpinnerLoaded();
        fileNodeByName.format(fileName).waitForHidden(DEFAULT_TIMEOUT_MS);
    }

    public void copyFile(String fileName, String copyName) {
        fileNodeByName.format(fileName).waitForVisible(DEFAULT_TIMEOUT_MS).click();
        fileActionsBtn.waitForVisible(DEFAULT_TIMEOUT_MS).click();
        fileActionsMenuItem.format("Copy").click();
        WebElement name = new WebElement(page, "xpath=//*[@data-testid='file-copy-name']", "fileCopyName");
        name.waitForVisible(DEFAULT_TIMEOUT_MS);
        name.fill(copyName);
        new WebElement(page, "xpath=//*[@data-testid='file-copy-submit']", "fileCopySubmit").click();
        waitUntilSpinnerLoaded();
        fileNodeByName.format(copyName).waitForVisible(DEFAULT_TIMEOUT_MS);
    }

    public void renameFile(String fileName, String newName) {
        fileNodeByName.format(fileName).waitForVisible(DEFAULT_TIMEOUT_MS).click();
        fileActionsBtn.waitForVisible(DEFAULT_TIMEOUT_MS).click();
        fileActionsMenuItem.format("Rename").click();
        WebElement name = new WebElement(page, "xpath=//*[@data-testid='file-move-name']", "fileMoveName");
        name.waitForVisible(DEFAULT_TIMEOUT_MS);
        name.fill(newName);
        new WebElement(page, "xpath=//*[@data-testid='file-move-submit']", "fileMoveSubmit").click();
        waitUntilSpinnerLoaded();
        fileNodeByName.format(newName).waitForVisible(DEFAULT_TIMEOUT_MS);
    }

    public void selectFile(String fileName) {
        fileNodeByName.format(fileName).waitForVisible(DEFAULT_TIMEOUT_MS).click();
    }

    public boolean isResourceNotFoundShown() {
        return getRootLocator().getLocator()
                .locator("xpath=.//*[not(*)][contains(normalize-space(.),'The resource is not found')]").count() > 0;
    }

    public boolean waitForFileSelectionDropped(String fileName) {
        return WaitUtil.waitForCondition(() -> !selectedFileParam().contains(fileName), DEFAULT_TIMEOUT_MS, 200,
                "Waiting for the Files tab to drop '" + fileName + "' from the URL selection");
    }

    public long waitForTreeToList(String fileName) {
        long started = System.currentTimeMillis();
        fileNodeByName.format(fileName).waitForVisible(TREE_LOAD_TIMEOUT_MS);
        long elapsed = System.currentTimeMillis() - started;
        LOGGER.info("Files tree listed '{}' after {} ms", fileName, elapsed);
        return elapsed;
    }

    public String describeFilePaneState(String expectedFileName) {
        String pane = filePaneLoading.exists() ? "loading"
                : filePreviewError.exists() ? "error: " + textOrNothing(filePreviewError)
                : filePreviewEmpty.exists() ? "empty"
                : "preview";
        return "tree lists '" + expectedFileName + "': " + fileNodeByName.format(expectedFileName).exists()
                + ", file pane: " + pane + ", url file param: '" + selectedFileParam() + "'";
    }

    private String textOrNothing(WebElement element) {
        try {
            return element.getLocator().first().innerText().replaceAll("\\s+", " ").trim();
        } catch (RuntimeException beingRedrawn) {
            return "(gone while being read)";
        }
    }

    public String selectedFileParam() {
        Matcher matcher = FILE_PARAM.matcher(page.url());
        return matcher.find() ? URLDecoder.decode(matcher.group(1), StandardCharsets.UTF_8) : "";
    }

    public boolean isFilePreviewEmptyShown() {
        return filePreviewEmpty.isVisible(DEFAULT_TIMEOUT_MS);
    }

    public boolean isNodePresent(String nodeName) {
        return fileNodeByName.format(nodeName).isVisible(DEFAULT_TIMEOUT_MS);
    }

    public void uploadFileAs(String filePath, String targetName, String targetFolder) {
        openAddMenuItem("files-upload");
        uploadInput.setInputFiles(filePath);
        if (targetName != null && !targetName.isEmpty()) {
            uploadNameField.waitForVisible(DEFAULT_TIMEOUT_MS).fill(targetName);
        }
        if (targetFolder != null && !targetFolder.isEmpty()) {
            uploadPathField.waitForVisible(DEFAULT_TIMEOUT_MS).fill(targetFolder);
        }
        uploadSubmitBtn.click();
        waitUntilSpinnerLoaded();
    }

    public boolean isAddMenuAvailable() {
        return addBtn.isVisible(DEFAULT_TIMEOUT_MS);
    }

    public void pickUpdateFile(String fileName, String newFilePath) {
        fileNodeByName.format(fileName).click();
        fileActionsBtn.waitForVisible(DEFAULT_TIMEOUT_MS).click();
        fileActionsMenuItem.format("Update").click();
        updateFileSubmitBtn.waitForVisible(FILE_DIALOG_TIMEOUT_MS);
        updateFileInput.setInputFiles(newFilePath);
    }

    public void confirmUpdateFile() {
        updateFileSubmitBtn.click();
        waitUntilSpinnerLoaded();
    }

    public boolean isUpdateFileNameWarningShown() {
        return updateFileNameWarning.isVisible(DEFAULT_TIMEOUT_MS / 2);
    }

    public void createFolder(String folderPath) {
        openAddMenuItem("files-new-folder");
        folderPathInput.fill(folderPath);
        folderSubmitBtn.click();
        waitUntilSpinnerLoaded();
    }

    private void openAddMenuItem(String itemTestId) {
        addBtn.hover();
        addMenuItem.format(itemTestId).click();
    }
}
