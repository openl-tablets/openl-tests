package domain.ui.webstudio.components.repositorytabcomponents;

import configuration.core.ui.WebElement;
import configuration.driver.DriverPool;
import domain.ui.webstudio.components.BaseComponent;
import helpers.utils.WaitUtil;


public class DeployModalComponent extends BaseComponent {

    private static final String MODAL_BASE = "//div[contains(@class,'ant-modal-container') and .//form[@id='deploy_form']]";

    private WebElement modal;
    private WebElement repositorySelect;
    private WebElement repositorySearchInput;
    private WebElement deploymentNameSelect;
    private WebElement deploymentNameSearchInput;
    private WebElement commentTextarea;
    private WebElement deployButton;
    private WebElement cancelButton;
    private WebElement successNotification;
    private WebElement errorNotification;
    private WebElement deploymentNameError;
    private WebElement firstDropdownOption;
    private WebElement dropdownOption;

    public DeployModalComponent() {
        super(DriverPool.getPage());
        initializeElements();
    }

    public DeployModalComponent(WebElement rootLocator) {
        super(rootLocator);
        initializeElements();
    }

    private void initializeElements() {
        modal = new WebElement(page, "xpath=" + MODAL_BASE, "deployModal");
        repositorySelect = new WebElement(page, "xpath=" + MODAL_BASE + "//div[contains(@class,'ant-select') and .//input[@id='deploy_form_repository']]//div[contains(@class,'ant-select-content')]", "repositorySelect");
        repositorySearchInput = new WebElement(page, "xpath=" + MODAL_BASE + "//input[@id='deploy_form_repository']", "repositorySearchInput");
        deploymentNameSelect = new WebElement(page, "xpath=" + MODAL_BASE + "//div[contains(@class,'ant-select') and .//input[@id='deploy_form_deploymentName']]//div[contains(@class,'ant-select-content')]", "deploymentNameSelect");
        deploymentNameSearchInput = new WebElement(page, "xpath=" + MODAL_BASE + "//input[@id='deploy_form_deploymentName']", "deploymentNameSearchInput");
        commentTextarea = new WebElement(page, "xpath=" + MODAL_BASE + "//textarea[@id='deploy_form_comment']", "commentTextarea");
        deployButton = new WebElement(page, "xpath=" + MODAL_BASE + "//div[contains(@class,'ant-modal-footer')]//button[contains(@class,'ant-btn-primary')]", "deployButton");
        cancelButton = new WebElement(page, "xpath=" + MODAL_BASE + "//div[contains(@class,'ant-modal-footer')]//button[not(contains(@class,'ant-btn-primary'))]", "cancelButton");
        firstDropdownOption = new WebElement(page, "xpath=//div[contains(@class,'ant-select-item') and contains(@class,'ant-select-item-option') and @title]", "firstDropdownOption");
        dropdownOption = new WebElement(page, "xpath=//div[contains(@class,'ant-select-item') and contains(@class,'ant-select-item-option') and @title='%s']", "dropdownOption");
        successNotification = new WebElement(page, "xpath=//div[contains(@class,'ant-notification')]//div[contains(@class,'ant-notification-notice-success')]", "successNotification");
        errorNotification = new WebElement(page, "xpath=(//div[contains(@class,'ant-notification')]//div[contains(@class,'ant-notification-notice-error')])[last()]", "errorNotification");
        deploymentNameError = new WebElement(page, "xpath=" + MODAL_BASE + "//input[@id='deploy_form_deploymentName']"
                + "/ancestor::div[contains(concat(' ', normalize-space(@class), ' '), ' ant-form-item ')][1]"
                + "//div[contains(@class,'ant-form-item-explain-error')]", "deploymentNameError");
    }

    public boolean isModalVisible() {
        return modal.isVisible(2000);
    }

    public DeployModalComponent waitForModal() {
        boolean modalAppeared = WaitUtil.waitForCondition(() -> isModalVisible(), DEFAULT_TIMEOUT_MS, 500, "Waiting for deploy modal to appear");
        if (!modalAppeared) {
            throw new RuntimeException("Deploy modal did not appear within timeout");
        }
        return this;
    }

    public DeployModalComponent selectRepository(String repositoryName) {
        repositorySelect.click();
        if (repositoryName != null) {
            dropdownOption.format(repositoryName).click();
        } else {
            firstDropdownOption.click();
        }
        return this;
    }

    public String getFocusedRepositoryInputBorderStyle() {
        return focusAndReadBorderStyle(repositorySelect, repositorySearchInput);
    }

    public String getFocusedDeploymentNameInputBorderStyle() {
        return focusAndReadBorderStyle(deploymentNameSelect, deploymentNameSearchInput);
    }

    private String focusAndReadBorderStyle(WebElement select, WebElement searchInput) {
        select.click();
        WaitUtil.requireCondition(() -> (Boolean) searchInput.getLocator().evaluate("input => document.activeElement === input"),
                DEFAULT_TIMEOUT_MS, 100, "Waiting for the search input of the field to take the focus");
        String borderStyle = searchInput.getCssValue("border-top-style");
        if ("true".equals(searchInput.getAttribute("aria-expanded"))) {
            page.keyboard().press("Escape");
            firstDropdownOption.waitForHidden(DEFAULT_TIMEOUT_MS);
        }
        return borderStyle;
    }

    public DeployModalComponent fillDeploymentName(String name) {
        deploymentNameSelect.click();
        deploymentNameSearchInput.fillSequentially(name).press("Tab");
        return this;
    }

    public DeployModalComponent selectExistingDeploymentName(String name) {
        deploymentNameSelect.click();
        dropdownOption.format(name).waitForVisible(DEFAULT_TIMEOUT_MS).click();
        return this;
    }

    public void deployToExistingDeployment(String repository, String deploymentName, String comment) {
        waitForModal();
        selectRepository(repository);
        selectExistingDeploymentName(deploymentName);
        fillComment(comment);
        clickDeploy();
    }

    public DeployModalComponent fillComment(String comment) {
        commentTextarea.fillSequentially(comment);
        return this;
    }

    public void clickDeploy() {
        deployButton.click();
    }

    public void clickCancel() {
        cancelButton.click();
    }

    public void deployWithAllFields(String repository, String deploymentName, String comment) {
        waitForModal();
        selectRepository(repository);
        fillDeploymentName(deploymentName);
        fillComment(comment);
        clickDeploy();
    }

    public void deployWithoutMandatoryFields() {
        waitForModal();
        clickDeploy();
    }

    public boolean isSuccessNotificationVisible() {
        return successNotification.isVisible(DEFAULT_TIMEOUT_MS);
    }
    public String getSuccessNotificationText() {
        successNotification.waitForVisible(DEFAULT_TIMEOUT_MS);
        return successNotification.getText().trim();
    }

    public String getErrorNotificationText() {
        errorNotification.waitForVisible(DEFAULT_TIMEOUT_MS);
        return errorNotification.getText().trim();
    }

    public boolean isDeploymentNameErrorShown() {
        return deploymentNameError.isVisible(DEFAULT_TIMEOUT_MS);
    }

    public String getDeploymentNameError() {
        return isDeploymentNameErrorShown() ? deploymentNameError.getText().trim() : "";
    }

    public boolean isDeployButtonEnabled() {
        return deployButton.isEnabled();
    }
}
